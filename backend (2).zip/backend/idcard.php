<?php 


if(!$_FILES['file']['error'])
	{
		
						
						$filename = $_POST['name'];
						
						$uploaddir = '../idcard/';
						$extensionArray = explode(".", $_FILES['file']['name']);
						$extension = end($extensionArray);
						$uploadfile = $uploaddir . $filename . "." . $extension;
						
						$filename = $uploadfile;
						
						if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadfile)) 
							{
										echo "File is valid, and was successfully uploaded.\n";
							} else {
										echo "Possible file upload attack!\n";
							}
		
					


	}
?>