<?php 
	require('fpdf/pdfstuff/fpdf.php');
	include "vars.php";
	include "utility.php";

	//if($_GET['action'] == "attest_reg"){
		$jambNumber = $_GET['jamb_no'];
		$biodataCompletionLevel = $_GET['biodataCompletionLevel'];
		
		if(updateBiodataCompletionLevel($jambNumber, $biodataCompletionLevel)){		
			$response['status'] = "success";
			$response['message'] = 'Registration were successfully completed.';		
		}
		else{
			$response['status'] = "error";
			$response['message'] = 'Registration were not successfully completed.';	
		}
	//}

	//$jambNumber = "11111111UI";				
	$connectionString = mysqli_connect($host,$uname,$pwd) ;
	if(!$connectionString){
		die();
	}
	else{
		mysqli_select_db($connectionString, $db);
		
		$sql = "SELECT * FROM appliedcandidates WHERE jambRegNo = '$jambNumber'";
		$result = mysqli_query($connectionString, $sql);
		if($result)
		{
			
			$candidateData = mysqli_fetch_object( $result);
			//echo $candidateData->jambRegNo;
		}else
		{
		  //echo mysqli_error($connectionString);  
		}
		/****************************************************************************************************************************************************
		 * get first sitting                                                                                                                                *
		 ****************************************************************************************************************************************************/
		mysqli_select_db($connectionString, $db);
		
		$sql = "SELECT * FROM applicant_olevels WHERE jamb_no = '$jambNumber'";
		$result = mysqli_query($connectionString, $sql);
		if($result)
		{ 
		  if(mysqli_num_rows($result)>0)
		  {
			$candidateResult1 = array();
			while( $data = mysqli_fetch_object( $result) )
			{
				  $candidateResult[] = $data;

			}
			$sittings = mysqli_num_rows($result);

		  }
		}else
		{
		  echo mysqli_error($connectionString);  
		}
		
		
		
  }
  	
	
	//////////////////////////// extracting the olevel results
	if($sittings == 1){
	  // only one result
	  $result1Holder = array();
	  $result1Holder = extract_the_result($candidateResult[0]);
	}
	else if ($sittings == 2){
	  // first result
	  $result1Holder = array();
	  $result1Holder = extract_the_result($candidateResult[0]);
	  /// second result
	  $result2Holder = array();
	  $result2Holder = extract_the_result($candidateResult[1]);
	}
	
	
	class PDF extends FPDF
	{
		function Footer(){
		  // Go to 1.5 cm from bottom
		  $this->SetY(-15);
		  // Select Arial italic 8
		  $this->SetFont('Arial','I',8);
		  // Print centered page number
		  $this->Cell(0,10,'Page '.$this->PageNo(),0,0,'R');
		}
	}
	
	
	$pdf = new FPDF();
	$pdf->AddPage();
	$pdf->SetFont('Arial','B',12);
	
	$pdf->Cell(0,10,'University of Ibadan',0,2, 'C');
	$pdf->SetFont('Arial','B',16);
	$pdf->Cell(0,10,'Admissions (2019/2020)',0,2, 'C');
	$pdf->Cell(0, 10, $pdf->Image('../images/UI logo.png',10,10,20,20), 0,2,'C');
	$pdf->SetFont('Arial','',11);
	$ref = 'Ref.:/UI/Admissions/DE/2019/'.$candidateData->jambRegNo ;
	$pdf->Cell(0,10,$ref,0,2, 'L');
	$pdf->SetFont('Arial','',11);
	
	$pdf->Cell(0,8,'............................................................................................................................................................................',0,1 );
	$pdf->SetFont('Arial','BU',13);
	$pdf->Cell(0,8,'Personal Information',0,1 );
	
	$pdf->SetFont('Arial','',11);
	$pdf->Cell(40,8,'Candidate Name',0,0 ); 
	$pdf->Cell(20,8,$candidateData->surname,0,0 );
	$pdf->Cell(20,8,$candidateData->firstname,0,0 );
	$pdf->Cell(20,8,$candidateData->middlename,0,1 );
	
	$pdf->Cell(40,8,'State of Origin',0,0 ); 
	$pdf->Cell(20,8,$candidateData->stateOfOrigin,0,1 );
	$pdf->Cell(40,8,'Date of Birth',0,0 ); 
	$pdf->Cell(20,8,$candidateData->dateOfBirth,0,1 );
	$pdf->Cell(40,8,'Sex',0,0 ); 
	$pdf->Cell(20,8,$candidateData->sex,0,1 );
	
	
	
	$pdf->Cell(0,8,'............................................................................................................................................................................',0,1 );
	$pdf->SetFont('Arial','BU',13);
	$pdf->Cell(0,8,'O Level Result',0,1 );
	$pdf->SetFont('Arial','',11);
	
	
	if($sittings == 1)
	{
	$firstSitting = "FIRST SITTING - " . $result1Holder[0]. " - ".$result1Holder[1];
	$pdf->SetFont('Arial','B',11);
	$pdf->Cell(90,8,$firstSitting,1,1,'L' );
	$pdf->SetFont('Arial','',11);
	$result1Holder[8] = "";
	
	} else if($sittings == 2)
	{
	//echo "number of sittings : " .$sittings;
	$firstSitting = "FIRST SITTING - " . $result1Holder[0]. " - ".$result1Holder[1];
	$secondSitting = "SECOND SITTING - " . $result2Holder[0]. " - ".$result2Holder[1];
	$pdf->SetFont('Arial','B',11);
	$pdf->Cell(90,8,$firstSitting,1,0,'C' );
	$pdf->Cell(10,8,'',0,0 );
	$pdf->Cell(90,8,$secondSitting,1,1,'C' ); 
	$pdf->SetFont('Arial','',11);
	
	  
	}
	
	
	for($i=1; $i<=6; $i++){
		$pdf->Cell(90,8,$result1Holder[$i+2],1,0,'L' ); 
		$pdf->Cell(10,8,'',0,0 );
		
		if($sittings < 2){
			$pdf->Cell(90,8,'',0,1,'C' );
		}
		else{
			$pdf->Cell(90,8,$result2Holder[$i+2],1,1,'L' );
		}
	}
	
	$pdf->SetFont('Arial','',11);
	
	$pdf->Cell(0,8,'............................................................................................................................................................................',0,1 );
	$pdf->SetFont('Arial','BU',13);
	$pdf->Cell(0,8,'JAMB Information',0,1 );
	$pdf->SetFont('Arial','',11);
	$pdf->Cell(40,8,'JAMB Number:',0,0 );
	$pdf->Cell(20,8,$candidateData->jambRegNo,0,1 );
	
	$pdf->Cell(40,8,'JAMB Score',0,0 );
	$pdf->Cell(20,8,$candidateData->jambScore,0,1 );
	
	$pdf->Cell(40,8,'Faculty',0,0 );
	$pdf->Cell(20,8,$candidateData->facultyApplyingTo,0,1 );
	
	$pdf->Cell(40,8,'Department',0,0 );
	$pdf->Cell(20,8,$candidateData->departmentApplyingTo,0,1 );
	
	
	$pdf->Cell(0,8,'............................................................................................................................................................................',0,1 );
	/////////////// calculate JAMB points
	$candidate_jamb_point = ($candidateData->jambScore / 400) * 50;
	$candidate_olevel_point = ($candidateData->olevel_score / 30) * 50 ;
	$total_point = $candidate_jamb_point + $candidate_olevel_point ;
	
	
	
	
	$pdf->SetFont('Arial','BU',13);
	$pdf->Cell(0,8,'Grades Computation',0,1 );
	$pdf->SetFont('Arial','',11);
	$pdf->Cell(60,8,'JAMB Number of Points:',0,0 );
	$pdf->Cell(20,8,$candidate_jamb_point,0,1 );
	
	$pdf->Cell(60,8,'O Level Number of Points:',0,0 );
	$pdf->Cell(20,8,$candidate_olevel_point,0,1 );
	
	$pdf->Cell(60,8,'Total Number of Points:',0,0 );
	$pdf->SetFont('Arial','BU',12);
	
	$pdf->Cell(20,8,$total_point,0,1 );
	
	$pdf->SetFont('Arial','',11);
	
	
	$pdf->Cell(0,8,'............................................................................................................................................................................',0,1 );
	
	$image_height = 150;
	$image_width = 150;
	$pdf->SetFont('Arial','BU',13);
	$pdf->Cell(0,8,'Scanned Result',0,1 );
	if($sittings ==1)
	{
	  $pdf->SetFont('Arial','',11);
	  $filename = '../documents/'.$jambNumber .'/'. $jambNumber . '_1' . '.jpg';
	  if (file_exists($filename)) {
			  $pdf->AddPage();
			  $pdf->Image($filename, $pdf->GetX(), $pdf->GetY(), $image_height, $image_width);
	
		  }else
		  {
			  $pdf->Cell(0,8,'First O Level result was not uploaded',0,1 );
		  }
	}
	else if($sittings == 2)
	{
	  $pdf->SetFont('Arial','BU',13);
	  /// first o' level result
	  $filename = '../documents/'.$jambNumber .'/'. $jambNumber . '_1' . '.jpg';
	  if (file_exists($filename)) {
			  $pdf->AddPage();
			  $pdf->Cell(0,8,'First O Level Result',0,1 );
			  $pdf->Image($filename, $pdf->GetX(), $pdf->GetY(), $image_height, $image_width);
	
		  }else
		  {
			  $pdf->AddPage();
			  $pdf->Cell(0,8,'First O Level result was not uploaded',0,1 );
		  }
	
		  /// second o' level result
	
		  $filename = '../documents/'.$jambNumber .'/'. $jambNumber . '_2' . '.jpg';
		  if (file_exists($filename)) {
			  $pdf->AddPage();
			  $pdf->Cell(0,8,'Second O Level Result',0,1 );
			  $pdf->Image($filename, $pdf->GetX(), $pdf->GetY(), $image_height, $image_width);
	
		  }else
		  {
			  $pdf->AddPage();
			  $pdf->Cell(0,8,'Second O Level result was not uploaded',0,1 );
	
		  }
	}
	
	$pdf1 = new PDF;
	$pdf1->Footer();
	$destination_filename = '../documents/'.$jambNumber .'/'. $jambNumber . '-info.pdf';
	if(file_exists($destination_filename))
	{
		unlink($destination_filename);
		$pdf->Output($destination_filename,'F');
	
	}
	else
	{
	
		$pdf->Output($destination_filename,'F');
	}
	
	echo json_encode($response);
	
	
	function extract_the_result($result_object)
	{
		$result = array();
		$result[0] = $result_object->exam_type;
		$result[1] = $result_object->exam_number;
		$result[2] = $result_object->scanned_copy;
		$result[3] = $result_object->sub1 . "  ( " . $result_object->grade1 . " )";
		$result[4] = $result_object->sub2 . "  ( " . $result_object->grade2 . " )";
		$result[5] = $result_object->sub3 . "  ( " . $result_object->grade3 . " )";
		$result[6] = $result_object->sub4 . "  ( " . $result_object->grade4 . " )";
		$result[7] = $result_object->sub5 . "  ( " . $result_object->grade5 . " )";
		$result[8] = $result_object->sub6 . "  ( " . $result_object->grade6 . " )";
		
		return  $result;
		/// `_id`, `jamb_no`, `exam_sitting`, `exam_type`, `exam_year`, `exam_month`, `exam_center`, `exam_number`, `scanned_copy`, `sub1`, `grade1`, `sub2`, `grade2`, `sub3`, `grade3`, `sub4`, `grade4`, `sub5`, `grade5`, `sub6`, `grade6` 
			
		
	}



?>