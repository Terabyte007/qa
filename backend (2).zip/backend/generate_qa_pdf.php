<?php
	////////////////////////////////////////// some used functions in the file //////////////////////////////////////////////////////////////////////
	//////////////////////// create empty single line
	function space($the_instance)
	{
		$the_instance->Cell(0,5,"" ,0,1,"L");
	}	
	
	//////////////// end of create empty single line
	
	////////////////////////// calculate_scores //////////////////////////////////////////////////////
	function calculate_score($records, $field_name)
	{
		$result = 0;
		foreach($records as $key => $value)
		{
			foreach($value as $key1 => $value1)
			{
				if($key1 == $field_name) $result += $value1;
			}
			
		}
		return ($result/count($records));	
	}
	
	////////////////////////// end of calculate_score ///////////////////////////////////////////////
	
	//////////////////// get current session ////////////////////////////////////////////////////////////
	function get_current_session($conn)
	{
		$session_sql = "SELECT * FROM `tbl_sessions` WHERE `is_current` = 1";
		$result_session = mysqli_query($conn, $session_sql);
		if($result_session && mysqli_num_rows($result_session)>0)
		{
			$current_session = mysqli_fetch_object($result_session);
		}else
		{$current_session = 0;}
		return $current_session; 
	}
	////////////////////////
	
	
	
	//////////////////// process_all_lecturers ////////////////////////////////////////////////////////////
	function process_all_lecturers($conn, $course_code, $dept_id_fk, $download_type, $current_session, $the_pf_number,  $type )
	{
		process_individual($conn, $course_code, $dept_id_fk, $download_type, $current_session, $the_pf_number, $type); //// both funcctions are the same
	}
	////////////////////////
	
	//////////////////// process_individual ////////////////////////////////////////////////////////////
	function process_individual($conn, $course_code, $dept_id_fk, $download_type, $current_session, $the_pf_number,  $type )
	{
		$sql = "SELECT * FROM `tbl_downloads` WHERE `dept_id_fk` LIKE '$dept_id_fk' AND `course_code` 
		                 LIKE '$course_code' AND `session_id` LIKE '$current_session' AND `pf_number` LIKE '$the_pf_number' AND `type` LIKE '$type'";
		$result = mysqli_query($conn, $sql);
		if($result && mysqli_num_rows($result)>0)
		{
			//do nothing
			//update_downlaod_table($conn, $course_code, $dept_id_fk, $download_type, $current_session, $the_pf_number);
		}else
		{
			insert_into_download_table($conn, $course_code, $dept_id_fk, $download_type, $current_session, $the_pf_number, $type);
		}
	}
	////////////////////////
	
	
	//////////////////// update_downlaod_table ////////////////////////////////////////////////////////////
	function insert_into_download_table($conn, $course_code, $dept_id_fk, $download_type, $current_session, $the_pf_number, $type)
	{
		$sql = "INSERT INTO `tbl_downloads`(`dept_id_fk`, `course_code`, `session_id`, `type_of_download`, `pf_number`, `type`) 
		          VALUES ('$dept_id_fk','$course_code','$current_session','$download_type','$the_pf_number', '$type')";
		$result = mysqli_query($conn, $sql);
		if($result)
		{
		}else
		{
		}
	}
	////////////////////////

	
	/////////////////////// notify the download table ///////////////////////////////////////////////////
	function notify_download_table($conn, $the_department_name, $dept_id_fk, $download_type, $current_session, $the_pf_number, $type )
	{
		if($download_type == 'individual') process_individual($conn, $the_department_name, $dept_id_fk, $download_type, 
		  $current_session,$the_pf_number, $type );
		if($download_type == 'all_lecturers') process_all_lecturers($conn, $the_department_name, $dept_id_fk, $download_type, 
		  $current_session,$the_pf_number,  $type );
	
	}
	
	

	/////////////////////// end of notify the download table ////////////////////////////////////////////

	
	///////////////////////// get coourses taught by the lecturer ///////////////////////////////////
	function get_courses_taught($conn, $pf_number)
	{
				  $courses = array();
				  $courses_sql = "SELECT `course_id_fk` FROM `course_lecturer` WHERE `pfnumber` = '$pf_number'";
				  $courses_result = mysqli_query($conn, $courses_sql);
				  if($courses_result && mysqli_num_rows($courses_result)>0)
				  {
					  while($row = mysqli_fetch_object($courses_result))
					  {
					  $courses[] =$row->course_id_fk;
					  }
				  }else
				  {
					  $courses[] = "no course";
				  }
		return $courses;
	}
	
	/////////////// get department name /////////////////////////////////////
	function get_department_name($conn, $dept_id_fk)
	{
				  $department_name = "";
				  $sql = "SELECT * FROM `tbl_departments` WHERE `id` = '$dept_id_fk'";
				  $result = mysqli_query($conn, $sql);
				  if($result && mysqli_num_rows($result)>0)
				  {
					  $row = mysqli_fetch_object($result);
					  $department_name = $row->title;
					 
				  }else
				  {
					  
				  }
		return $department_name;
	}
	////////////////////// end of get department name
	
	
	///////////////////////// end of get course taught by the lecturer function //////////////////////////////
	function get_number_of_students($conn, $the_course, $current_session)
	{
				  $number_of_students_sql = "SELECT * FROM `tbl_course_registered` WHERE `course_id_fk` LIKE '3124' AND `session_id_fk` = '$current_session'";
				  $students_result = mysqli_query($conn, $number_of_students_sql);
				  if($students_result && mysqli_num_rows($students_result)>0)
				  {
					$number_of_students = mysqli_num_rows($students_result);
				  }else
				  {
					$number_of_students = 0;
				  }
		return $number_of_students;
	}
	/////////////////////////// students that regitered for the course /////////////////////////////////////////
	
	/////////////////////////// end of students that regitered for the course //////////////////////////////////

////////////////////////////////////////// end of some used functions in the file //////////////////////////////////////////////////////////////

///////////////////////////////// generate_pdf //////////////////////////////////////////////////////////////
if(isset($_GET['generate_pdf']))
	{
	  if(($_GET['generate_pdf']=="yes"))
		{
			require('fpdf/pdfstuff/fpdf.php');
			include "vars.php";
		
			class PDF extends FPDF
			{
				function Footer(){
				  // Go to 1.5 cm from bottom
				  $this->SetY(-15);
				  // Select Arial italic 8
				  $this->SetFont('Arial','I',8);
				  // Print centered page number
				  $this->Cell(0,10,'Page '.$this->PageNo(),0,0,'R');
				}
			}
		  header("Content-Type: application/json");
		  $connectionString = mysqli_connect($host,$uname,$pwd, $db) ;
		  $response = array();
		  if(!$connectionString)
			  {
				  $response["status"] = "Connection Problems";
				  echo json_encode($response);
			  }else
			  {
			  $data = file_get_contents("php://input");
			  $data = json_decode($data);
			  $data = $data->pdf_info;
			  //echo json_encode($data);
			  $dept_id_fk = $data->dept_id_fk;
			  $donwload_parameters = $data->donwload_parameters;
			  $download_type = $donwload_parameters->download_type;
			  if($download_type == 'individual') $course_id = $data->donwload_parameters->lecturer_info->course_id_fk;
			  //echo json_encode($course_id);
			  if($download_type != 'All Lecturers') $pf_number = $data->donwload_parameters->lecturer_info->pf_number;

			  //echo json_encode($pf_number);
			  $where_clause = " WHERE `dept_id_fk` = '$dept_id_fk'";
			  $download_type == 'All Lecturers'? $where_clause :$where_clause .= " AND `pf_number` ='$pf_number'";
			  $the_department_name = get_department_name($connectionString, $dept_id_fk);
			  //echo $where_clause;
			  ////////////////////////////////// get all the lecturers in the department /////////////////////////////////////////////////
			  $lecturers = array();
			  $departmental_lecturers_sql = "SELECT * FROM `tbl_lecturers`" . $where_clause;
			  //echo $departmental_lecturers_sql;
			  $department_lecturer_result = mysqli_query($connectionString, $departmental_lecturers_sql);
			  if($department_lecturer_result && mysqli_num_rows($department_lecturer_result)>0)
			  {
				  while($row = mysqli_fetch_object($department_lecturer_result))
				  {
				  $lecturers[] =$row;
				  }
				  //echo json_encode($lecturers);
			  }else
			  {
				  $lecturers[] = "no lecturer";
			  }
			  //echo json_encode($lecturers);
			  ////////////////////////////// end of get all the lecturers in the department /////////////////////////////////////////////////
				  
				//////////////////////////////////////////////////////// database data retrival /////////////////////////////////////////////////////////////
				
				////////////////////////array of features ///////////////////////////////////////////////////////////////////////////
				
				$assessment_features1 = array(	'enthusiasm_1', 
												'enthusiasm_2', 
												'warmth_1', 
												'warmth_2', 
												'warmth_3', 
												'credibility_1', 
												'credibility_2', 
												'credibility_3', 
												'expectation_for_success_1', 
												'expectation_for_success_2', 
												'expectation_for_success_3', 
												'expectation_for_success_4', 
												'enco_and_patient_1', 
												'enco_and_patient_2', 
												'professional_1', 
												'professional_2', 
												'professional_3', 
												'professional_4', 
												'adaptability_1', 
												'knowledgeability_1', 
												'knowledgeability_2', 
												'pedagody_1', 
												'pedagody_2', 
												'pedagody_3', 
												'assess_of_students_1', 
												'assess_of_students_2', 
												'assess_of_students_3');
				/////////////////////// end of array of features /////////////////////////////////////////////////////////////////////

				//////////////////////////// number of items in each lecture feature
				$lecture_features = array();
				$sql = "SELECT * FROM lecture_features";
				$result_features = mysqli_query($connectionString, $sql);
				if($result_features && mysqli_num_rows($result_features)>0)
				{
					while($row = mysqli_fetch_object($result_features))
					{
					$lecture_features[] =$row;
					}
				}else
				{
					$lecture_feature_title[] = "no features";
				}
				////////////////////////////// end of items in each lecture feature
				
				//////////////////////////// get the sub-questions for each assessment
				$sub_lecture_features = array();
	
				$sql = "SELECT * FROM `sub_lecturer_features`";
				$result_sub_features = mysqli_query($connectionString, $sql);
				if($result_sub_features && mysqli_num_rows($result_sub_features)>0)
				{
					while($row = mysqli_fetch_object($result_sub_features))
					{
					$sub_lecture_features[] =$row;
					}
				}else
				{
					$lecture_feature_title[] = "no sub-features";
				}
				////////////////////////////// end of items in each lecture feature
				
				//////////////////////////// get current session
	
				$current_session = get_current_session($connectionString);
				////////////////////////////// end of get current session

			$pdf = new FPDF();
			//echo json_encode($lecturers);
			if($lecturers[0] != "no lecturer")
			 {
			
			///////////////////////// begining of eacch lecturer loop
			//echo json_encode($lecturers);
			  foreach($lecturers as $lecturer) 
				{ 
				  //echo "this is the lecturrer ";
					//echo json_encode($lecturer);
					 $courses_taught = array();
					 $courses_taught = get_courses_taught($connectionString, $lecturer->pf_number);
					 /*	 echo "pfnumber "; echo $lecturer->pf_number;
						 echo "pfnumber "; echo $pf_number;*/
						 //echo "course taught  "; echo json_encode($courses_taught);
						
					 if($courses_taught[0] != "no course")
					  {
						foreach($courses_taught as $course_t)
						{
							//echo $course_t;echo " ";  echo $lecturer->pf_number ;
							//////////////////////////// get lecturer assessment with each course at a time
							mysqli_select_db($connectionString, $db);
							$lecturer_assessment = array();
							$sql = "SELECT t1.`pf_number`, t1.`student_id_fk`, t1.`course_id_fk`, t1.`enthusiasm_1`, t1.`enthusiasm_2`, t1.`warmth_1`, 
									t1.`warmth_2`, t1.`warmth_3`, t1.`credibility_1`,t1.`credibility_2`, t1.`credibility_3`, t1.`expectation_for_success_1`,
									t1.`expectation_for_success_2`,t1.`expectation_for_success_3`,t1.`expectation_for_success_4`, t1.`enco_and_patient_1`,
									t1.`enco_and_patient_2`, t1.`professional_1`,t1.`professional_2`, t1.`professional_3`,t1.`professional_4`, t1.`adaptability_1`,
									t1.`knowledgeability_1`, t1.`knowledgeability_2`,t1.`pedagody_1`, t1.`pedagody_2`,t1.`pedagody_3`, t1.`assess_of_students_1`,
									t1.`assess_of_students_2`, t1.`assess_of_students_3`,t1.`any_other_comment`,	t1.`comparative_analysis`, t1.`total_score`,
									t1.`session_id_fk`, t2.`dept_id_fk`, t2.`surname`, t2.`onames`,t2.`titles`,t2.`pf_number`, t3.`id`, t3.`faculty_id_fk`, 
									t3.`title` as department_name,t4.`id`,t4.`faculty`,t5.`_id`, t5.`code` as course_code, t5.`title` as course_title 
									FROM assessment_submission t1 
									INNER JOIN tbl_lecturers t2 on t1.pf_number = t2.pf_number 
									INNER JOIN tbl_departments t3 on t2.dept_id_fk = t3.id 
									INNER JOIN tbl_faculty t4 on t3.faculty_id_fk = t4.id
									INNER JOIN tbl_courses t5 on t1.course_id_fk = t5._id 
									WHERE  t1.pf_number = '$lecturer->pf_number' 
									and t1.session_id_fk = '$current_session->_id' and t1.`course_id_fk` = '$course_t'";
							  $result = mysqli_query($connectionString, $sql);
							  if($result && mysqli_num_rows($result)>0)
							  {
								  $assessors = mysqli_num_rows($result);
								  while($row = mysqli_fetch_object($result))
								  {
								  $lecturer_assessment[] =$row;
								  }

							  }else
							  {
								  $lecturer_assessment[] = "no assessments";
							  }
							////////////////////////////// end of get lecturer assessment
							if($lecturer_assessment[0] != "no assessments")
							{
								//echo json_encode($lecturer_assessment);
								////////////////////////////// begining of PDf generation //////////////////////////////////////////////////////
								/////////////////////////// assessment headings
								//$pdf = new FPDF();
								$pdf->AddPage();
								$pdf->SetFont('Arial','B',12);
								$pdf->Cell(0,8,'University of Ibadan',0,2, 'C');
								$pdf->SetFont('Arial','B',16);
								$pdf->Cell(0,7,'Quality Assurance Directorate',0,2, 'C');
								$pdf->SetFont('Arial','B',13);
								
								$pdf->SetFont('Arial','B',11);
								$pdf->Cell(0,7,"Student's Assessment of Teaching Effectiveness Scale",0,2, 'C');
								$pdf->Cell(0,7,$current_session->session,0,2, 'C');
				
								$pdf->Cell(0, 5, $pdf->Image('../images/UI logo.png',10,10,20,20), 0,2,'C');
								$pdf->Cell(0, 1, $pdf->Image('../photo/' .$lecturer_assessment[0]->pf_number .'.jpg',180,10,20,20), 0,2,'C');
								$pdf->Cell(35,5,'Lecturer Name:',0,0, 'L');
								$pdf->SetFont('Arial','',10);
								$pdf->Cell(35,5,$lecturer_assessment[0]->titles. ' ' . $lecturer_assessment[0]->surname . ' ' . $lecturer_assessment[0]->onames,0,1, 'L');
								$pdf->SetFont('Arial','B',10);
								$pdf->Cell(35,5,'Faculty:',0,0, 'L');
								$pdf->SetFont('Arial','',10);
								$pdf->Cell(35,5,$lecturer_assessment[0]->faculty ,0,1, 'L');
								$pdf->SetFont('Arial','B',10);
								$pdf->Cell(35,5,'Department:',0,0, 'L');
								$pdf->SetFont('Arial','',10);
								$pdf->Cell(35,5,$lecturer_assessment[0]->department_name ,0,1, 'L');
								$pdf->SetFont('Arial','B',10);
								$pdf->Cell(35,5,'Course:',0,0, 'L');
								$pdf->SetFont('Arial','',10);
								$pdf->Cell(35,5,$lecturer_assessment[0]->course_code . ' - '. $lecturer_assessment[0]->course_title  ,0,1, 'L');
								$pdf->SetFont('Arial','B',10);
								$pdf->Cell(35,5,'No. of Students:',0,0, 'L');
								$pdf->SetFont('Arial','',10);
								$pdf->Cell(35,5,$assessors . " of " . get_number_of_students($connectionString, $course_t, 
									get_current_session($connectionString)->_id),0,1, 'L');
								$pdf->SetFont('Arial','B',10);
								
								$pdf->Cell(35,5,'PF Number:',0,0, 'L');
								$pdf->SetFont('Arial','',10);
								$pdf->Cell(35,5,$lecturer_assessment[0]->pf_number,0,1, 'L');
							
								$pdf->Cell(35,5,'',0,1, 'L');
								////////////////////// end of the assessment heading
				
								///////////////////// begining of table
									/////////////table heading
									$pdf->SetFont('Arial','',7);
									$pdf->Cell(0,7,'The rating is as follows 1: Poor 2: Fair 3: Good 4: Very Good 5: Excellent',1,1, 'C');
									$pdf->SetFont('Arial','B',9);
								
									$pdf->Cell(35,5,'Lecture Features',1,0, 'L');
									$pdf->Cell(120,5,'Lecture Sub Features',1,0, 'L');
									$pdf->Cell(7,5,'5',1,0, 'C');
									$pdf->Cell(7,5,'4',1,0, 'C');
									$pdf->Cell(7,5,'3',1,0, 'C');
									$pdf->Cell(7,5,'2',1,0, 'C');
									$pdf->Cell(7,5,'1',1,1, 'C');
								///////////////// end of table heading
								//////////////////////// recursively generate the lecture features
								if($lecture_features[0] != "no features")
								{
										foreach($lecture_features as $features)
										{
											$cell_heights = 5;
											$row_span = $features->sub_features * $cell_heights;
											$pdf->SetFont('Arial','',8);
											$pdf->Cell(35,$row_span,$features->title,1,0,"C");
												if($sub_lecture_features[0] != "no sub-features")
													{ $counter = 0;
														foreach($sub_lecture_features as $key => $sub_features)
															{
																if($features->id == $sub_features->parent_id_fk)
																	{ 	
																		$pdf->SetFont('Arial','',7.5);
																		if($counter == 0)
																		{
																			$pdf->Cell(120,$cell_heights,$sub_features->title,1,0,"L");
																			$pdf->Cell(7,5,calculate_score($lecturer_assessment,$assessment_features1[$key])>4 
																					   && calculate_score($lecturer_assessment,$assessment_features1[$key]) <=5 ?"X":"",1,0,"C");
																			$pdf->Cell(7,5,calculate_score($lecturer_assessment,$assessment_features1[$key])>3
																						&& calculate_score($lecturer_assessment,$assessment_features1[$key])<= 4?"X":"",1,0,"C");
																			$pdf->Cell(7,5,calculate_score($lecturer_assessment,$assessment_features1[$key])>2
																						&& calculate_score($lecturer_assessment,$assessment_features1[$key])<= 3?"X":"",1,0,"C");
																			$pdf->Cell(7,5,calculate_score($lecturer_assessment,$assessment_features1[$key])> 1
																						&& calculate_score($lecturer_assessment,$assessment_features1[$key])<= 2?"X":"",1,0,"C");
																			$pdf->Cell(7,5,calculate_score($lecturer_assessment,$assessment_features1[$key])>0
																						&& calculate_score($lecturer_assessment,$assessment_features1[$key])<= 1?"X":"",1,1,"C");
																		
																		}else
																		{
																		  $pdf->Cell(35,$row_span,"",0,0,"C");
																			$pdf->Cell(120,$cell_heights,$sub_features->title,1,0,"L");
																			$pdf->Cell(7,5,calculate_score($lecturer_assessment,$assessment_features1[$key])>4 
																					   && calculate_score($lecturer_assessment,$assessment_features1[$key]) <=5 ?"X":"",1,0,"C");
																			$pdf->Cell(7,5,calculate_score($lecturer_assessment,$assessment_features1[$key])>3
																						&& calculate_score($lecturer_assessment,$assessment_features1[$key])<= 4?"X":"",1,0,"C");
																			$pdf->Cell(7,5,calculate_score($lecturer_assessment,$assessment_features1[$key])>2
																						&& calculate_score($lecturer_assessment,$assessment_features1[$key])<= 3?"X":"",1,0,"C");
																			$pdf->Cell(7,5,calculate_score($lecturer_assessment,$assessment_features1[$key])> 1
																						&& calculate_score($lecturer_assessment,$assessment_features1[$key])<= 2?"X":"",1,0,"C");
																			$pdf->Cell(7,5,calculate_score($lecturer_assessment,$assessment_features1[$key])>0
																						&& calculate_score($lecturer_assessment,$assessment_features1[$key])<= 1?"X":"",1,1,"C");
																		
																		}
																		$counter++;
																	}
																}// 
													}else
													{
														$pdf->Cell(0,$cell_heights,"No sub-featrure for assessment",1,0,"C");
													}
										 } //// end of foreach lecturer feature
								}else
								{
									$pdf->Cell(0,$cell_heights,"No features for assessment",1,0,"C");
								}
								if(calculate_score($lecturer_assessment,'comparative_analysis') > 4) $remark =  "Oustanding"; 
								if(calculate_score($lecturer_assessment,'comparative_analysis')>3 && 
								   calculate_score($lecturer_assessment,'comparative_analysis')<=4) $remark =  "Above Average"; 
								if(calculate_score($lecturer_assessment,'comparative_analysis')>2 && 
								   calculate_score($lecturer_assessment,'comparative_analysis')<=3) $remark =  "Average"; 
								if(calculate_score($lecturer_assessment,'comparative_analysis')>1 && 
								   calculate_score($lecturer_assessment,'comparative_analysis')<=2) $remark =  "Below Average"; 
								if(calculate_score($lecturer_assessment,'comparative_analysis')>0 && 
								   calculate_score($lecturer_assessment,'comparative_analysis')<=1) $remark =  "Poor"; 
								$pdf->Cell(155,$cell_heights,"Comparison with other lecturers in this University",1,0,"R");
								$pdf->Cell(35,5,$remark,1,1,"C");
							
								$pdf->SetFont('Arial','B',10);
								
								$pdf->Cell(155,$cell_heights,"Average Score",1,0,"R");
								$pdf->Cell(35,5,calculate_score($lecturer_assessment,'total_score'),1,1,"C");
								space($pdf);
								$pdf->SetFont('Arial','B',10);
								$pdf->Cell(0,5,"Other Comments by Students" ,0,1,"L");
								$pdf->SetFont('Arial','',9);
								//space($pdf);
								///////////// any other comment	section					
								foreach($lecturer_assessment as $key => $value )
								{
									$pdf->Cell(0,5,$key+1 . " )  " . $value->any_other_comment . "." ,0,1,"L");
								}
								/////////////// end of any comment section
								if($download_type == 'Individual Lecturer')
								{
									$pdf1 = new PDF;
									$pdf1->Footer();
									$destination_filename = '../documents/'. $lecturer_assessment[0]->pf_number ."_". $lecturer_assessment[0]->course_code .
									   ".pdf";
									$the_pf_number = $lecturer_assessment[0]->pf_number;
									$the_course_code = $lecturer_assessment[0]->course_code;
									
									if(file_exists($destination_filename))
									{
										unlink($destination_filename);
										$pdf->Output($destination_filename,'F');
									}
									else
									{
										$pdf->Output($destination_filename,'F');
									}
									$pdf = new FPDF();
									//////////////////// save information in the download table
									$current_session = get_current_session($connectionString);
									//echo json_encode ($current_session);
									notify_download_table($connectionString, $the_course_code, $dept_id_fk, "individual",
									 $current_session->_id, $the_pf_number, 'pdf');
									 
									//////////////////// end of save information in the download table
								}
							} ///// no assessment. therefore do not do anything
							} //////////// end of foreach course
								
						} ////////////// no course

				} //////////////////// end of for each lectuer
				   
					 
		
				if($download_type == 'All Lecturers')
						{
							$pdf1 = new PDF;
							$pdf1->Footer();
							$destination_filename = '../documents/'. $the_department_name . ".pdf";
							if(file_exists($destination_filename))
							{
								unlink($destination_filename);
								$pdf->Output($destination_filename,'F');
							
							}
							else
							{
								$pdf->Output($destination_filename,'F');
							}
							$pdf = new FPDF();
							//////////////////// save information in the download table
							 notify_download_table($connectionString, $the_department_name, $dept_id_fk, 
							  "all_lecturers", $current_session->_id,$the_department_name, 'pdf');
							 
							//////////////////// end of save information in the download table
							
						}
		
				////////////////// output /////previous algorithm concept
				$response['status'] = "done";
				if($download_type == 'All Lecturers')
				{
					 $response['type'] = "All Lecturers"; 
					 $response['filename'] = $the_department_name . ".pdf"; 
				}else{
					$response['type'] = "Individual Lecturer";
					 //$response['filename'] = $lecturer_assessment[0]->pf_number ."_". $lecturer_assessment[0]->course_code . ".pdf" ; 
				}
				/////////////// end of previous algorithm concept
				echo json_encode($response);
						
				} ////////////////////// no lecturer
				{
					///////////////// no lecturer; send a message
				}
			
		} ///////////////////// end of database conncectionstring
	} ////// end of generate_pdf being == yes
} ////////////////// end of generate_pdf isset
?>