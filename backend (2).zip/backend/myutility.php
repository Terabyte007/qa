<?php



	
	//////////////////// process_all_lecturers ////////////////////////////////////////////////////////////
	function process_all_lecturers($conn, $course_code, $dept_id_fk, $download_type, $current_session, $the_pf_number)
	{
		process_individual($conn, $course_code, $dept_id_fk, $download_type, $current_session, $the_pf_number); //// both funcctions are the same
	}
	////////////////////////
	
	//////////////////// process_individual ////////////////////////////////////////////////////////////
	function process_individual($conn, $course_code, $dept_id_fk, $download_type, $current_session, $the_pf_number, $type)
	{
		$sql = "SELECT * FROM `tbl_downloads` WHERE `dept_id_fk` LIKE '$dept_id_fk' AND `course_code` 
		                 LIKE '$course_code' AND `session_id` LIKE '$current_session' AND `pf_number` LIKE '$the_pf_number' AND `type` LIKE '$type'";
		$result = mysqli_query($conn, $sql);
		if($result && mysqli_num_rows($result)>0)
		{
			//do nothing
			//update_downlaod_table($conn, $course_code, $dept_id_fk, $download_type, $current_session, $the_pf_number);
		}else
		{
			insert_into_download_table($conn, $course_code, $dept_id_fk, $download_type, $current_session, $the_pf_number, $type);
		}
	}
	////////////////////////
	
	
	//////////////////// update_downlaod_table ////////////////////////////////////////////////////////////
	function insert_into_download_table($conn, $course_code, $dept_id_fk, $download_type, $current_session, $the_pf_number, $type)
	{
		$sql = "INSERT INTO `tbl_downloads`(`dept_id_fk`, `course_code`, `session_id`, `type_of_download`, `pf_number`, `type`) 
		          VALUES ('$dept_id_fk','$course_code','$current_session','$download_type','$the_pf_number', '$type')";
		$result = mysqli_query($conn, $sql);
		if($result)
		{
		}else
		{
		}
	}
	////////////////////////

	
	/////////////////////// notify the download table ///////////////////////////////////////////////////
	function notify_download_table($conn, $the_department_name, $dept_id_fk, $download_type, $current_session, $the_pf_number, $type )
	{
		if($download_type == 'individual' || $download_type == 'university_wide' || 
		      $download_type == 'departmental') process_individual($conn, $the_department_name, $dept_id_fk, $download_type, 
		  $current_session,$the_pf_number, $type);
		if($download_type == 'all_lecturers') process_all_lecturers($conn, $the_department_name, $dept_id_fk, $download_type, 
		  $current_session,$the_pf_number, $type);
	
	}
	


//////////////////// function get faculty id 
function fn_get_faculty_id ( $faculty_name , $conn )
{
	$sql ="SELECT id FROM `tbl_faculty` WHERE `faculty` = '$faculty_name'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					$row = mysqli_fetch_object($result);
					return $row->id; 
				}else
				{
					return "";
				}
		}else
		{
		  return "";
		}
}
/////////////////////////////// end of function faculty id


//////////////////// function get faculty id 
function get_number_of_students ($session , $course_id, $conn )
{
	$sql ="SELECT * FROM `tbl_course_registered` WHERE `course_id_fk` LIKE '$course_id' AND `session_id_fk` = '$session' ";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					//$row = mysqli_fetch_object($result);
					return mysqli_num_rows($result); 
				}else
				{
					return 0;
				}
		}else
		{
		  return 0;
		}
}
/////////////////////////////// end of function faculty id




//////////////////////////// get coourse id

function fn_get_course_id($conn, $course)
{
	$sql ="SELECT id FROM `tbl_registration_courses`  WHERE `course_code` = '$course'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					$row = mysqli_fetch_object($result);
					return $row->id; 
				}else
				{
					return "";
				}
		}else
		{
		  return "";
		}
}

/////////////////////////// end of get course id








///////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////// fn_get_all_users /////////////////////////////////////////////////

function fn_get_all_users( $array_of_dept , $conn, $the_user_type, $type)
{
	$data = array();
	if( $type == 1)
	{
		foreach($array_of_dept as $dept_id)
		{
		$sql ="SELECT * FROM `users` t1 inner join `tbl_user_type` t3 on t1.userType = t3._id inner join 
		`tbl_staff` t2 on t1.username = t2.pf_number WHERE t3.`type` = '$the_user_type' and t2.dept_id_fk = '$dept_id'";
		$result = mysqli_query($conn,$sql);
		if($result)
			{
				if(mysqli_num_rows($result)>0)
					{
					  while($row = mysqli_fetch_object($result)) 
						  {
							$data[] = $row;	
						  }
					}else
					{
						
					}
			}else
			{
			  
			}
		}
	} 
	else if ($type == 2)
	{
	$sql ="SELECT * FROM `users` t1 inner join `tbl_user_type` t3 on t1.userType = t3._id inner join `tbl_staff` t2 on t1.username = t2.pf_number WHERE t3.`type` = '$the_user_type'";
	$result = mysqli_query($conn,$sql);
	  if($result)
		  {
			  if(mysqli_num_rows($result)>0)
				  {
					while($row = mysqli_fetch_object($result)) 
					{
					  $data[] = $row;	
					}
					
				  }else
				  {
				  }
		  }else
		  {
		  }	
	
	}
	return $data;
}


///////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////// end of  fn_get_all_users //////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////// get all the departments id in the given faculty /////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////
function fn_get_dept($connectionString, $faculty_id)
{
	$data1 = array();
	$sql ="SELECT * FROM `tbl_departments` where `faculty_id_fk` = '$faculty_id'";
	$result = mysqli_query($connectionString,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					while($row = mysqli_fetch_object($result)) 
					  {
						$data1[] = $row->id;	
					  }
				}else
				{
				}
		}else
		{
		}

	return $data1;
}
////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////// end of get all the departments id in the given faculty///////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////


//////////////////// function get lecturer id 
function fn_get_lecturer_id ( $conn )
{
	$sql ="SELECT * FROM `tbl_portfolio` WHERE `name` = 'Lecturer'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					$row = mysqli_fetch_object($result);
					return $row->id; 
				}else
				{
					return "";
				}
		}else
		{
		  return "";
		}
}

/////////////////////// get leturer id in the usertype table
function fn_get_lecturer_id2 ( $conn )
{
	$sql ="SELECT * FROM `tbl_user_type` WHERE `type` = 'lecturer'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					$row = mysqli_fetch_object($result);
					return $row->_id; 
				}else
				{
					return "";
				}
		}else
		{
		  return "";
		}
}

////////////////////////// end of get lecturer id in the usertype table

/////////////////////////// check for course assignment
function fn_check_for_assignment($conn, $dept_id, $course_id )
{
 $sql = "SELECT * FROM `tbl_lecturer_course_map` WHERE department_id_fk ='$dept_id' and `course_id_fk` = '$course_id'";
 $result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					return true ;
				}else
				{
					return false;
				}
		}else
		{
		  return false;
		}	
}
/////////////////////////// end of check for course assignment

/////////////////////// get leturer id in staff  table
function fn_get_lecturer_id3 ( $conn, $pf_number )
{
	$sql ="SELECT _id FROM `tbl_staff` WHERE `pf_number` = '$pf_number'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					$row = mysqli_fetch_object($result);
					return $row->_id; 
				}else
				{
					return "";
				}
		}else
		{
		  return "";
		}
}

////////////////////////// end of get lecturer id in the usertype table



//////////////////// function get title id 
function fn_get_title_id ( $title, $conn )
{
	$sql ="SELECT * FROM `tbl_titles` WHERE `title_name` = '$title'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					$row = mysqli_fetch_object($result);
					return $row->id; 
				}else
				{
					return "";
				}
		}else
		{
		  return "";
		}
}

//////////////////// function get lecturer id 
function fn_get_dean_id ( $conn )
{
	$sql ="SELECT * FROM `tbl_portfolio` WHERE `name` = 'Dean'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					$row = mysqli_fetch_object($result);
					return $row->id; 
				}else
				{
					return "";
				}
		}else
		{
		  return "";
		}
}





function fn_get_department_id ( $department_name , $conn )
{
	$sql = "SELECT id FROM `tbl_departments` WHERE `title`  = '$department_name'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					$row = mysqli_fetch_object($result);
					return $row->id; 
				}else
				{
					return "";
				}
		}else
		{
		  return "";
		}
}


///////////////////// function get department name rom department id
function fn_get_department_name( $conn, $dept_id)
{
$sql = "SELECT title FROM `tbl_departments` WHERE `id`  = '$dept_id'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					$row = mysqli_fetch_object($result);
					return $row->title; 
				}else
				{
					return "";
				}
		}else
		{
		  return "";
		}	
	
	
	
}

//////////////// end of get department name from department id
function fn_get_level_id ( $level , $conn )
{
	$sql = "SELECT _id FROM `tbl_levels` WHERE `level` = '$level'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					$row = mysqli_fetch_object($result);
					return $row->_id; 
				}else
				{
					return "";
				}
		}else
		{
		  return "";
		}
}

function get_current_session($conn)
	{
		$session_sql = "SELECT * FROM `tbl_sessions` WHERE `is_current` = 1";
		$result_session = mysqli_query($conn, $session_sql);
		if($result_session && mysqli_num_rows($result_session)>0)
		{
			$current_session = mysqli_fetch_object($result_session);
		}else
		{$current_session = 0;}
		return $current_session; 
	}


function fn_get_current_session_id($conn)
{
	$sql = "SELECT * FROM `tbl_sessions` WHERE `is_current` = 1";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					$row = mysqli_fetch_object($result);
					return $row->_id; 
				}else
				{
					return "";
				}
		}else
		{
		  return "";
		}
}



function fn_get_session_id($conn, $session)
{ 
	$sql = "SELECT * FROM `tbl_sessions` WHERE `session` = '$session'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					$row = mysqli_fetch_object($result);
					return $row->_id; 
				}else
				{
					return "";
				}
		}else
		{
		  return "";
		}
}


function fn_get_potfolio_id($conn, $potfolio)
{
	$sql = "SELECT * FROM `tbl_portfolio` WHERE `name` = '$potfolio'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					$row = mysqli_fetch_object($result);
					return $row->id; 
				}else
				{
					return "";
				}
		}else
		{
		  return "";
		}

}


function fn_get_current_semester_id($conn)
{
	$sql = "SELECT * FROM `tbl_semesters` WHERE `is_current` = 1";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					$row = mysqli_fetch_object($result);
					return $row->id; 
				}else
				{
					return "";
				}
		}else
		{
		  return "";
		}
}


///////////////////// check if whosoever is a staff
function fn_check_for_potfoliohood( $pf, $conn, $potfolio)
{
	$potfolio_id = fn_get_potfolio_id($conn, $potfolio);
	$sql = "SELECT * FROM `tbl_staff` WHERE `pf_number` = '$pf' and `pfid` = '$potfolio_id'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					return true; 
				}else
				{
					return false;
				}
		}else
		{
		  return false;
		}
}

///////////////////// check if whosoever is a staff
function fn_check_for_staffhood( $pf, $conn )
{
	$sql = "SELECT * FROM `tbl_staff` WHERE `pf_number` = '$pf'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					return true; 
				}else
				{
					return false;
				}
		}else
		{
		  return false;
		}
}


function fn_check_students_transactions($conn, $student_id, $session_id)
{
	$sql = "SELECT * FROM `tbl_students_transactions` WHERE `student_id_fk` = '$student_id' and session_id_fk = '$session_id'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					return true; 
				}else
				{
					return false;
				}
		}else
		{
		  return false;
		}
}


function fn_get_student_id($conn, $matric_no)
{
	$sql = "SELECT * FROM `tbl_students_master` WHERE `matricNo` = '$matric_no'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					$row = mysqli_fetch_object($result);
					return $row->_id; 
				}else
				{
					return "";
				}
		}else
		{
		  return "";
		}
}



///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// 				get course code id 							///////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function fn_get_course_code_id($conn, $course_code)
{
	$sql = "SELECT * FROM `tbl_registration_courses` WHERE `course_code` LIKE '$course_code'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					$row = mysqli_fetch_object($result);
					return $row->id; 
				}else
				{
					return "";
				}
		}else
		{
		  return "";
		}
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////					end of get course code id				///////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// 				get course code id 							///////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function fn_get_semester_id($conn, $semester)
{
	$sql = "SELECT * FROM `tbl_semesters` WHERE `term_name` LIKE '$semester'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					$row = mysqli_fetch_object($result);
					return $row->id; 
				}else
				{
					return "";
				}
		}else
		{
		  return "";
		}
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////					end of get course code id				///////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function fn_get_department_id_from_pf($f_conn, $f_pf_number)
{
	$sql = "SELECT * FROM `tbl_staff` WHERE `pf_number` = '$f_pf_number'";
	$result = mysqli_query($f_conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					$row = mysqli_fetch_object($result);
					return $row->dept_id_fk; 
				}else
				{
					return "";
				}
		}else
		{
		  return "";
		}	
	
}
/////////////////// pf of previous portfolio holder
function fn_get_previous_portfolio_holder_pf($f_conn, $f_potfolio_id, $department_id)
{
$sql = "SELECT pf_number FROM `tbl_staff` where `dept_id_fk` = '$department_id' && `pfid` = '$f_potfolio_id'";	
$result = mysqli_query($f_conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					$row = mysqli_fetch_object($result);
					return $row->pf_number; 
				}else
				{
					return "";
				}
		}else
		{
		  return "";
		}	
	
}
////////////////////// emd of pf of previous portfolio holder 


function fn_depotfolioise_existing_portfolio($f_conn,$f_pf_number, $f_potfolio_id)
{
	$department_id = fn_get_department_id_from_pf($f_conn, $f_pf_number);
	$lecturer_id = fn_get_lecturer_id($f_conn) ;
	if( $f_potfolio_id == 1 || $f_potfolio_id == 2  ) 
	{
		$lecturer_id2 = fn_get_lecturer_id2($f_conn);
		$pf_of_previous_portfolio_holder = fn_get_previous_portfolio_holder_pf($f_conn, $f_potfolio_id, $department_id);
		$sql = "UPDATE `users` SET `userType` = '$lecturer_id2' WHERE `username` = '$pf_of_previous_portfolio_holder';";
		$result = mysqli_query($f_conn,$sql);
		if($result)
		  {
		  }else
		  {
			
		  }
	}
	
		if($department_id != "" && $lecturer_id != "")
			{$sql = "UPDATE `tbl_staff` SET `pfid` = '$lecturer_id' where `dept_id_fk` = '$department_id' && `pfid` = '$f_potfolio_id'";
			$result = mysqli_query($f_conn,$sql);
			if($result)
				{
				 	return "ok"; 	 
				}else
				{
					return "not ok";
				}
		  }else
		  {
			  return "not ok";
		  }	
		  
			
		

}

///////////////////////////// reduce to lecturer

function fn_reduce_to_lecturer($f_conn,$f_pf_number)
{
			$sql = "UPDATE `users` SET `userType` = '5' WHERE `username` = '$f_pf_number';";
			$result = mysqli_query($f_conn,$sql);
			if($result)
				{
					return "ok"; 
				}else
				{
				  return "not ok";
				}
		

}
///////////////////////////// end of reduce to lecturer

//////////////////////////////// get assessments
function fn_get_the_departments( $conn)
{
	$current_session = fn_get_current_session_id($conn);
	$response = array();
	$sql = "SELECT DISTINCT(t3.id) as department FROM assessment_submission t1 inner join tbl_lecturers t2 on t1.pf_number = t2.pf_number inner join tbl_departments
	       t3 on t2.dept_id_fk = t3.id inner join tbl_faculty t4 on t3.faculty_id_fk = t4.id INNER JOIN tbl_courses t5 on t5._id = t1.course_id_fk 
		   WHERE t1.session_id_fk = '$current_session'";
			
	$result = mysqli_query($conn,$sql);
	if($result)
		{
		  $data = array();
		  if(mysqli_num_rows($result)>0)
			  { 
				while ($row = mysqli_fetch_object($result))
				{
					$data[] = $row->department;	
				}
				$response['status'] = "ok";
				$response["data"] = $data;

				return $response;
			  }else
			  {
				$response['status'] = "not ok";
				$response["data"] = "";
				return $response;

			  }
			}else
			{
				  $response['status'] = "not ok";
				  $response["data"] = "";
				  return $response;

			}
	
}


//////////////////////////////// end of get assessments
//////////////////////////////// get assessments
function fn_get_assessment( $conn, $where)
{
	$current_session = fn_get_current_session_id($conn);
	$response = array();
	$sql = "SELECT  concat( t2.`titles`, ' ', t2.`surname`,' ', t2.`onames`) as lecturer_name, t5.`code`, t5.`title` as course_title, t1.`pf_number`,
	        t1.`enthusiasm_1`, t1.`enthusiasm_2`, t1.`warmth_1`, t1.`warmth_2`, t1.`warmth_3`, t1.`credibility_1`, t1.`credibility_2`, t1.`credibility_3`,
			t1.`expectation_for_success_1`, t1.`expectation_for_success_2`, t1.`expectation_for_success_3`, t1.`expectation_for_success_4`, t1.`enco_and_patient_1`,
			t1.`enco_and_patient_2`, t1.`professional_1`, t1.`professional_2`, t1.`professional_3`, t1.`professional_4`, t1.`adaptability_1`, t1.`knowledgeability_1`,
			t1.`knowledgeability_2`, t1.`pedagody_1`, t1.`pedagody_2`, t1.`pedagody_3`, t1.`assess_of_students_1`, t1.`assess_of_students_2`, 
			t1.`assess_of_students_3`, t1.`any_other_comment`, t1.`comparative_analysis` as compare_with_others, t1.`total_score`, t3.`title` 
			as dept_name,t4.`faculty` as faculty_name 
			FROM assessment_submission t1 
			inner join tbl_lecturers t2 
			on t1.pf_number = t2.pf_number
			inner join tbl_departments t3
			on t2.dept_id_fk = t3.id
			inner join tbl_faculty t4
			on t3.faculty_id_fk = t4.id
			INNER JOIN tbl_courses t5
			on t5._id = t1.course_id_fk
			WHERE t1.session_id_fk = '$current_session'" . $where;
			
	$result = mysqli_query($conn,$sql);
	if($result)
		{
		  $data = array();
		  if(mysqli_num_rows($result)>0)
			  { 
				while ($row = mysqli_fetch_object($result))
				{
					$data[] = $row;	
				}
				$theField = mysqli_fetch_fields($result);
				$response['status'] = "ok";
				$response["data"] = $data;
				$response["fields"] = $theField;
				return $response;
			  }else
			  {
				$response['status'] = "not ok";
				$response["data"] = "";
				$response["fields"] = "";
				return $response;

			  }
			}else
			{
				  $response['status'] = "not ok";
				  $response["data"] = "";
				  $response["fields"] = "";	
				  return $response;

			}
	
}


//////////////////////////////// end of get assessments

//////////////////////////////// get dynamic course assignment template
function fn_get_registration( $conn, $dept_id)
{
	$response = array();
	$sql = "SELECT surname as surname, othernames as othernames, pf_number as PF_Number FROM `tbl_staff` WHERE `dept_id_fk` = '$dept_id' ";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
		  $data = array();
		  if(mysqli_num_rows($result)>0)
			  { 
				while ($row = mysqli_fetch_object($result))
				{
					$data[] = $row;	
				}
				$theField = mysqli_fetch_fields($result);
				$response['status'] = "ok";
				$response["data"] = $data;
				$response["fields"] = $theField;
				return $response;
			  }else
			  {
				$response['status'] = "not ok";
				$response["data"] = "";
				$response["fields"] = "";
				return $response;

			  }
			}else
			{
				  $response['status'] = "not ok";
				  $response["data"] = "";
				  $response["fields"] = "";	
				  return $response;

			}
	
}


//////////////////////////////// end of get dynamic course registration template

//////////////////////////////////////// update course assignment to lecturer

function fn_update_course_assignment($conn, $lecturer, $department, $course_id )
{
	//echo " this is the course ".$course;
		//$course_id = fn_get_course_id($conn, $course);
	//echo " this is the course id ".$course_id;
		$sql = "UPDATE `tbl_lecturer_course_map` SET lecturer_id_fk ='$lecturer' WHERE  department_id_fk = '$department' and course_id_fk = '$course_id'";
		$result = mysqli_query($conn,$sql);
		if($result)
			{
				return "Reassigned"; 
			}else
			{
			  return "not_Reassigned";
			}
		
}


/////////////////////////////////////// end of course assignment to lecturer 

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// 			update session 														////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function fn_update_sessions($conn, $the_current_session, $is_current)
{
		fn_clear_sessions($conn);
		$sql = "UPDATE `tbl_sessions` SET `is_current` = '$is_current' where `session` = '$the_current_session'";
		$result = mysqli_query($conn,$sql);
		if($result)
			{
				return "ok"; 
			}else
			{
			  return "not ok";
			}
		
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////	end of update session											.///////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// 			clear current session 														////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function fn_clear_sessions($conn)
{
		$sql = "UPDATE `tbl_sessions` SET `is_current` = '0'";
		$result = mysqli_query($conn,$sql);
		if($result)
			{
				return "ok"; 
			}else
			{
			  return "not ok";
			}
		
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////	end of clear session											.///////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////// 			insert into session 												////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

function fn_insert_into_sessions($conn, $the_current_session, $is_current)
{
	fn_clear_sessions($conn);
	$sql = "INSERT INTO `tbl_sessions`(`session`, `is_current`) VALUES ('$the_current_session','$is_current');";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			return "ok"; 
		}else
		{
		  return "notok";
		}
		
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////	end of insert into session										.///////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//////////////////////////////// inseert new course asssignment to into the lecturer course map table

function fn_insert_course_assignment($conn, $lecturer , $department, $course)
{
	//echo "inserrtion side";
	//echo "I am testing please";
	//echo $lecturer;

	$course_id = fn_get_course_id($conn, $course);
	$sql = "INSERT INTO `tbl_lecturer_course_map`(`lecturer_id_fk`, `department_id_fk`, `course_id_fk`) VALUES ('$lecturer', '$department', '$course_id' );";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			return "ok"; 
		}else
		{
		  return "not ok";
		}
		
}

/////////////////////////////// end of inseert new course asssignment to into the lecturer course map table
////////////////// insertion of staff into the staff table
function fn_potfolioise($conn, $pf_number, $potfolio)
{
	$potfolio_id = fn_get_potfolio_id($conn, $potfolio);
	$depotfolioise_response = fn_depotfolioise_existing_portfolio($conn,$pf_number, $potfolio_id);
	if($potfolio_id != "" )
		{$sql = "UPDATE `tbl_staff` SET `pfid` = '$potfolio_id' where `pf_number` = '$pf_number'";
		$result = mysqli_query($conn,$sql);
		if($result)
			{
				return "ok"; 
			}else
			{
			  return "not ok";
			}
		}else
		{
			return "not ok";
		}
}


////////////////// insertion of staff into the staff table
function fn_deanise($conn, $pf_number, $potfolio)
{
	$potfolio_id = fn_get_potfolio_id($conn, $potfolio);
	if($potfolio_id != "")
		{$sql = "UPDATE `tbl_staff` SET `pfid` = '$potfolio_id' where `pf_number` = '$pf_number'";
		$result = mysqli_query($conn,$sql);
		if($result)
			{
				return "ok"; 
			}else
			{
			  return "not ok";
			}
		}else
		{
			return "not ok";
		}
}


function fn_get_user_type_id($conn, $user_type)
{
	$sql = "SELECT _id FROM `tbl_user_type` WHERE `type` = '$user_type'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					$row = mysqli_fetch_object($result);
					return $row->_id; 
				}else
				{
					return "";
				}
		}else
		{
		  return "";
		}
}



///////////////////// check if whosoever is a staff
function fn_delete_user_account( $conn, $pf, $user_type )
{ 
	$user_type_id = fn_get_user_type_id($conn, $user_type);
	$sql = "DELETE FROM `users` WHERE `username` = '$pf' and `userType` = '$user_type_id'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			return true; 
		}else
		{
			return false;
		}
}

///////////////////// check if whosoever is a staff
function fn_check_for_user_account( $conn, $pf, $user_type )
{ 
	$user_type_id = fn_get_user_type_id($conn, $user_type);
	$sql = "SELECT * FROM `users` WHERE `username` = '$pf' and `userType` = '$user_type_id'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					return true; 
				}else
				{
					return false;
				}
		}else
		{
		  return false;
		}
}


function fn_create_user_account($conn, $pf_number, $user_type, $surname )
{
	$user_type_id = fn_get_user_type_id($conn, $user_type);
	$sql = "INSERT INTO `ui_rms`.`users` 
	       (`username`, `userpassword`,
		   `userType`, `sq_id_fk`, `sq_answer`) VALUES ('$pf_number', SHA1('$surname'),  '$user_type_id', '0', '')";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			return "ok"; 
		}else
		{
		  return "notok";
		}
}

function fn_insert_staff($conn,$title, $surname, $othernames, $pf_number, $department, $faculty, $type)
{
	//echo "inside insert staff";
	if($type == "mass") 
	{
		$department = fn_get_department_id ($department , $conn );
		$title = fn_get_title_id ($title , $conn );
	}
	$faculty = fn_get_faculty_id ($faculty , $conn );
	$sql = "INSERT INTO `tbl_staff`(`faculty_id_fk`,`dept_id_fk`,`surname`, `othernames`, `title_id_fk`,`pf_number`) 
	        VALUES ('$faculty', '$department','$surname','$othernames','$title','$pf_number')";
	$result = mysqli_query($conn,$sql);
	//echo mysqli_error($conn);
	if($result)
		{
			return "ok"; 
		}else
		{
		  return "notok";
		}
}


function fn_insert_into_tbl_lecturers($conn, $title, $surname, $middlename, $firstname, $dept_id_fk, $pf_number )
{
	$names = $firstname . " " . $middlename;
	$sql = "INSERT INTO `tbl_lecturers`(titles, surname, onames, dept_id_fk, pf_number) 
	         VALUES ('$title', '$surname', '$names', '$dept_id_fk', '$pf_number')";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			return "ok"; 
		}else
		{
		  return "notok";
		}
}

function fn_insert_into_tbl_courses($conn, $course_code, $course_title, $course_units, $course_dept_id_fk, $course_semester, $course_status)
{
	$sql = "INSERT INTO `tbl_courses`(`code`, `title`,`unit`, `dept_id_fk`, `semester`, `status`)VALUES ('$course_code','$course_title',
									 '$course_units', '$course_dept_id_fk','$course_semester', '$course_status')";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			return "ok"; 
		}else
		{
		  return "notok";
		}
}




function fn_insert_into_students_master($conn, $data, $session, $faculty_id )
{
	$matriculation_number = $data->matriculation_number;
	$level = fn_get_level_id ( $data->level , $conn );
	$surname = $data->surname;
	$firstname = $data->firstname;
	$middlename = $data->middlename;
	$department = fn_get_department_id ($data->department , $conn );
	//$faculty = $data->faculty;
	$gender = $data->gender;
	$sql = "INSERT INTO `tbl_students_master`( `matricNo`, `surname`, `firstname`, `middlename`, `gender_id`, `session_admitted_id_fk`,`faculty_id_fk`, `department_id_fk`) 
	         VALUES ('$matriculation_number','$surname','$firstname','$middlename','$gender','$session','$faculty_id','$department')";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			return "ok"; 
		}else
		{
		  return "notok";
		}
}

//////////////////// continue from this place. finish up this function
function fn_insert_into_students_transactions($conn, $data, $session_id, $student_id )
{
	$department = $data->department;
	$gender = $data->gender;
	$data->level = fn_get_level_id ( $data->level , $conn );
	$sql = "INSERT INTO `tbl_students_transactions`(`student_id_fk`, `session_id_fk`, `lev_id_fk`, `has_registered`) VALUES ('$student_id','$session_id','$data->level','1')";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			return "ok"; 
		}else
		{
		  return "notok";
		}
}


function fn_course_owner_id( $dept, $conn)
{
	$sql = "SELECT id FROM `tbl_department` WHERE `title` = '$dept'";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			if(mysqli_num_rows($result)>0)
				{
					$row = mysqli_fetch_object($result);
					return $row->id; 
				}else
				{
					return "";
				}
		}else
		{
		  return "";
		}
}


//////////////////// continue from this place. finish up this function
function fn_insert_into_registration_courses($conn, $course_title, $course_unit, $course_code, $department, $type )
{
	$type == 'multiple' ? $department = fn_get_department_id($department,$conn) : $department = $department;
	$sql = "INSERT INTO `tbl_registration_courses`(`course_code`, `course_title`, `course_unit`, `course_owner_id`) VALUES ('$course_code','$course_title','$course_unit','$department')";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			return "ok"; 
		}else
		{
		  return "notok";
		}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////// insertion into registered courses 							////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function fn_insert_into_registered_courses($conn,$matric_number, $course_code, $course_unit, $level, $semester, $status, $current_session_id )
{
	$student_id = fn_get_student_id($conn,$matric_number);
	$course_code_id = fn_get_course_code_id($conn, $course_code);
	$level_id = fn_get_level_id ($level, $conn);
	$semester_id = fn_get_semester_id($conn, $semester);
	//echo "course code is  " .$course_code . " and course code id is " . $course_code_id. " level id is " . $level_id;
	
	if($student_id == "" || $course_code_id =="")
	{
		return "notok";
	}else
	{
		
		$sql = "INSERT INTO `tbl_course_registered`(`student_id_fk`, `course_id_fk`, `course_units`, `level_id_fk`, `semester_id_fk`, `status`, `session_id_fk`) VALUES ('$student_id','$course_code_id','$course_unit','$level_id','$semester_id','$status','$current_session_id');";
		$result = mysqli_query($conn,$sql);
		if($result)
		  {
			  return "ok"; 
		  }else
		  {
			return "notok";
		  }
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////// end of insertion into registered courses 							////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


function fn_insert_into_faculty($conn, $faculty_title )
{
	$sql = "INSERT INTO `tbl_faculty`(`faculty`) VALUES ('$faculty_title')";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			return "ok"; 
		}else
		{
		  return "notok";
		}
}



//////////////////// continue from this place. finish up this function
function fn_insert_into_department($conn, $department_title, $faculty_title )
{
	$faculty_id = fn_get_faculty_id($faculty_title,$conn);
	$sql = "INSERT INTO `tbl_departments`(`faculty_id_fk`, `title`) VALUES ('$faculty_id','$department_title')";
	$result = mysqli_query($conn,$sql);
	if($result)
		{
			return "ok"; 
		}else
		{
		  return "notok";
		}
}
class cl_myUtitlity
{
    public $matriculation_number;
    public $surname;
    public $firstname;
    public $middlename;
    public $gender;
    public $session;
    public $semester;
    public $faculty;
    public $department;
    public $level;
	
    function __construct( $data )
	{
		$mydata = $data ;
		$this->level = $data['level'];
		$this->matriculation_number = $data['matriculation_number'];
		$this->surname = $mydata['surname'];
		$this->firstname = $mydata['firstname'];
		$this->middlename = $mydata['middlename'];
		$this->gender = $mydata['gender'];
		$this->session = $mydata['session'];
		$this->semester = $mydata['semester'];
		$this->faculty = $mydata['faculty'];
		$this->department = $mydata['department'];
		
	}

    
}


?>