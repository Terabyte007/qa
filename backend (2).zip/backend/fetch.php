<?php
session_start();
if(isset($_GET['what']))
	{
	if($_GET['what']=='countries')
		{	
		include "vars.php";
		header("Content-Type: application/json");
		
					$connectionString = mysqli_connect($host,$uname,$pwd) ;
						if(!$connectionString)
						{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "failed";
												$PersonalInfo_response["data"] = "";
												echo json_encode($response);
						}
						else
						{
								mysqli_select_db($connectionString, $db);
									$sql = "SELECT * FROM countries";
										
											
								$result = mysqli_query($connectionString,$sql);
									if($result)
									
									{
										//$row =mysqli_fetch_object($result);
										if(mysqli_num_rows($result)>0)
											{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "ok";
												while($row = $result->fetch_assoc()) {
													$arr[] = $row;	
												}
												$PersonalInfo_response["data"] = $arr;
												echo json_encode($PersonalInfo_response);
											}else{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "not ok";
												$PersonalInfo_response["data"] = "";
												echo json_encode($PersonalInfo_response);
											}
									}
									else
									{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "not ok";
												$PersonalInfo_response["data"] = "";
												echo json_encode($PersonalInfo_response);
									}
									
									
								
									
										
						}
		
		}
	
	}
	
///////////////////////// End of fectch country	

// fetch states in country if Nigeria

if(isset($_GET['what']))
	{
	if($_GET['what']=='state')
		{	
		include "vars.php";
		header("Content-Type: application/json");
		
					$connectionString = mysqli_connect($host,$uname,$pwd) ;
						if(!$connectionString)
						{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "failed";
												$PersonalInfo_response["data"] = "";
												echo json_encode($response);
						}
						else
						{
								mysqli_select_db($connectionString, $db);
									$sql = "SELECT * FROM state";
										
											
								$result = mysqli_query($connectionString,$sql);
									if($result)
									
									{
										$row =mysqli_fetch_object($result);
										if(mysqli_num_rows($result)>0)
											{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "ok";
												while($row = $result->fetch_assoc()) {
													$arr[] = $row;	
												}
												$PersonalInfo_response["data"] = $arr;
												echo json_encode($PersonalInfo_response);
											}else{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "not ok";
												$PersonalInfo_response["data"] = "";
												echo json_encode($PersonalInfo_response);
											}
									}
									else
									{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "not ok";
												$PersonalInfo_response["data"] = "";
												echo json_encode($PersonalInfo_response);
									}
									
									
								
									
										
						}
		
		}
	}
/////////// end of select state


// begining of select lgas


if(isset($_GET['what']))
	{
	if($_GET['what']=='lga')
		{	
		include "vars.php";
		header("Content-Type: application/json");
		$data = file_get_contents("php://input");
						$data = json_decode($data);
						$nameOftState = $data->stateName;
		
					$connectionString = mysqli_connect($host,$uname,$pwd) ;
						if(!$connectionString)
						{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "failed";
												$PersonalInfo_response["data"] = "";
												echo json_encode($response);
						}
						else
						{
								mysqli_select_db($connectionString, $db);
									$stateId = fetchStateId($nameOftState);
									//echo $stateId;
									$sql = "SELECT * FROM lga WHERE stateId='$stateId'";
										
											
								$result = mysqli_query($connectionString,$sql);
									if($result)
									
									{
										//$row =mysqli_fetch_object($result);
										if(mysqli_num_rows($result)>0)
											{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "ok";
												while($row = $result->fetch_assoc()) {
													$arr[] = $row;	
												}
												$PersonalInfo_response["data"] = $arr;
												echo json_encode($PersonalInfo_response);
											}else{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "not ok";
												$PersonalInfo_response["data"] = "";
												echo json_encode($PersonalInfo_response);
											}
									}
									else
									{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "not ok";
												$PersonalInfo_response["data"] = "";
												echo json_encode($PersonalInfo_response);
									}
									
									
								
									
										
						}
		
		}
	}



function  fetchStateId($state)
{
	include "vars.php";
			$connectionString = mysqli_connect($host,$uname,$pwd) ;
				if(!$connectionString)
				{
										$PersonalInfo_response = array();
										$PersonalInfo_response["status"] = "failed";
										$PersonalInfo_response["data"] = "";
										echo json_encode($response);
				}
				else
				{
						mysqli_select_db($connectionString, $db);
							$sql = "SELECT stateId FROM state WHERE state = '$state'";
								
									
						$result = mysqli_query($connectionString,$sql);
							if($result)
							
							{
								$row =mysqli_fetch_object($result);
								if(mysqli_num_rows($result)>0)
									{
										
										
										return $row->stateId;
									}else{
										
										return "error";
									}
							}
							else
							{
										
										return "error";
							}
								
				}
	
	}



// begining of select lgas


if(isset($_GET['what']))
	{
	if($_GET['what']=='saveApplicant')
		{	
		include "vars.php";
		header("Content-Type: application/json");
		$data = file_get_contents("php://input");
						$data = json_decode($data);
						$surname = $data->surname;
						$firstname = $data->firstname;
						$lastname = $data->lastname;
						$homeTown = $data->homeTown;
						$nationality = $data->nationality;
						$state = $data->state;
						$lga = $data->lga;
						$gender = $data->gender;
						$maritalStatus = $data->maritalStatus;
						//echo $nationality; $satte;
		
					$connectionString = mysqli_connect($host,$uname,$pwd) ;
						if(!$connectionString)
						{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "failed";
												$PersonalInfo_response["data"] = "";
												echo json_encode($response);
						}
						else
						{
								mysqli_select_db($connectionString, $db);
		/*`applicantId`, `applicantSurname`, `applicantFirstname`, `applicantLastname`, `applicantHomeTown`, `applicantLga`, `applicantState`, `applicantNationality`*/
									//echo $stateId; `applicantGender``applicantMaritalStatus`
									$sql = "SELECT * FROM applicant_personal WHERE applicantSurname='$surname' AND applicantFirstname='$firstname' AND applicantLastname='$lastname' AND applicantHomeTown ='$homeTown' AND applicantGender ='$gender' AND applicantMaritalStatus ='$maritalStatus'";
										
											
								$result = mysqli_query($connectionString,$sql);
									if($result)
									
									{
										//$row =mysqli_fetch_object($result);
										if(mysqli_num_rows($result)>0)
											{
												
											$sql = "UPDATE applicant_personal SET applicantSurname = '$surname', applicantFirstname = '$firstname', applicantLastname = '$lastname', applicantHomeTown ='$homeTown', applicantLga='$lga', applicantState='$state', applicantNationality = '$nationality', applicantGender ='$gender', applicantMaritalStatus ='$maritalStatus' WHERE applicantSurname='$surname' AND applicantFirstname='$firstname' AND applicantLastname='$lastname' AND applicantHomeTown ='$homeTown' AND applicantMaritalStatus ='$maritalStatus' AND  applicantGender ='$gender' ";
													$result = mysqli_query($connectionString,$sql);
														if($result)
														{	$PersonalInfo_response = array();
															$PersonalInfo_response["status"] = "ok";
															$PersonalInfo_response["message"] = "Your Data was Updated Successfully";
															echo json_encode($PersonalInfo_response);
														}else{
															$PersonalInfo_response = array();
															$PersonalInfo_response["status"] = "not ok";
															$PersonalInfo_response["message"] = "Your Data was Not  Updated Successfully";
															echo json_encode($PersonalInfo_response);
														
														}
											}else{
											$sql = "INSERT INTO applicant_personal (applicantSurname, applicantFirstname, applicantLastname, applicantHomeTown, applicantLga, applicantState, applicantNationality, applicantGender, applicantMaritalStatus ) VALUES('$surname', '$firstname', '$lastname', '$homeTown', '$lga', '$state', '$nationality', '$gender', '$maritalStatus')";
											$result = mysqli_query($connectionString,$sql);
														if($result)
														{	
															$PersonalInfo_response = array();
															$PersonalInfo_response["status"] = "ok";
															$PersonalInfo_response["message"] = "Your Data was Saved Successfully";
															echo json_encode($PersonalInfo_response);
														}else{
															$PersonalInfo_response = array();
															$PersonalInfo_response["status"] = "not ok";
															$PersonalInfo_response["message"] = "Your Data was Not Successfully Saved";
															echo json_encode($PersonalInfo_response);
														
														}
											}
									}
									else
									{
															$PersonalInfo_response = array();
															$PersonalInfo_response["status"] = "not ok";
															$PersonalInfo_response["message"] = "Your Data was Not Successfully Saved";
															echo json_encode($PersonalInfo_response);
									}
									
									
								
									
										
						}
		
		}
	}






// begining of select lgas


if(isset($_GET['what']))
	{
	if($_GET['what']=='getNumber')
		{	
		include "vars.php";
		header("Content-Type: application/json");
		$data = file_get_contents("php://input");
						$data = json_decode($data);
						$surname = $data->surname;
						$firstname = $data->firstname;
						$lastname = $data->lastname;
						$homeTown = $data->homeTown;
						$nationality = $data->nationality;
						$state = $data->state;
						$lga = $data->lga;
						//echo $nationality; $satte;
		
					$connectionString = mysqli_connect($host,$uname,$pwd) ;
						if(!$connectionString)
						{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "failed";
												$PersonalInfo_response["data"] = "";
												echo json_encode($response);
						}
						else
						{
								mysqli_select_db($connectionString, $db);
		/*`applicantId`, `applicantSurname`, `applicantFirstname`, `applicantLastname`, `applicantHomeTown`, `applicantLga`, `applicantState`, `applicantNationality`*/
									//echo $stateId;
									$sql = "SELECT * FROM applicant_personal WHERE applicantSurname='$surname' AND applicantFirstname='$firstname' AND applicantLastname='$lastname' AND applicantHomeTown ='$homeTown'";
										
											
								$result = mysqli_query($connectionString,$sql);
									if($result)
									
									{
															$PersonalInfo_response = array();
															$PersonalInfo_response["status"] = "ok";
															while($row = $result->fetch_assoc()) {
																$arr[] = $row;	
															}
															$PersonalInfo_response["data"] = $arr;
															$PersonalInfo_response["message"] = "";
															echo json_encode($PersonalInfo_response);
										
									}
									else
									{
															$PersonalInfo_response = array();
															$PersonalInfo_response["status"] = "not ok";
															$PersonalInfo_response["message"] = "";
															echo json_encode($PersonalInfo_response);
									}
									
									
								
									
										
						}
		
		}
	}





//// fetch applicants
if(isset($_GET['what']))
	{
	if($_GET['what']=='applicants')
		{	
		include "vars.php";
		header("Content-Type: application/json");
		
					$connectionString = mysqli_connect($host,$uname,$pwd) ;
						if(!$connectionString)
						{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "failed";
												$PersonalInfo_response["data"] = "";
												echo json_encode($response);
						}
						else
						{
								mysqli_select_db($connectionString, $db);
									$sql = "SELECT * FROM applicant_personal WHERE approval!='YES'";
										
											
								$result = mysqli_query($connectionString,$sql);
									if($result)
									
									{
										//$row =mysqli_fetch_object($result);
										if(mysqli_num_rows($result)>0)
											{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "ok";
												while($row = $result->fetch_assoc()) {
													$arr[] = $row;	
												}
												$PersonalInfo_response["data"] = $arr;
												echo json_encode($PersonalInfo_response);
											}else{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "not ok";
												$PersonalInfo_response["data"] = "";
												echo json_encode($PersonalInfo_response);
											}
									}
									else
									{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "not ok";
												$PersonalInfo_response["data"] = "";
												echo json_encode($PersonalInfo_response);
									}
									
									
								
									
										
						}
		
		}
	
	}
	

// end of fetch applicants

//// fetch applicants
if(isset($_GET['what']))
	{
	if($_GET['what']=='applicant')
		{	
		include "vars.php";
		header("Content-Type: application/json");
		$data = file_get_contents("php://input");
						$data = json_decode($data);
						$id = $data->id;
		
					$connectionString = mysqli_connect($host,$uname,$pwd) ;
						if(!$connectionString)
						{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "failed";
												$PersonalInfo_response["data"] = "";
												echo json_encode($response);
						}
						else
						{
								mysqli_select_db($connectionString, $db);
									$sql = "SELECT * FROM applicant_personal WHERE applicantId= '$id'";
										
											
								$result = mysqli_query($connectionString,$sql);
									if($result)
									
									{
										//$row =mysqli_fetch_object($result);
										if(mysqli_num_rows($result)>0)
											{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "ok";
												while($row = $result->fetch_assoc()) {
													$arr[] = $row;	
												}
												$PersonalInfo_response["data"] = $arr;
												echo json_encode($PersonalInfo_response);
											}else{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "not ok";
												$PersonalInfo_response["data"] = "";
												echo json_encode($PersonalInfo_response);
											}
									}
									else
									{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "not ok";
												$PersonalInfo_response["data"] = "";
												echo json_encode($PersonalInfo_response);
									}
									
									
								
									
										
						}
		
		}
	
	}
	

// end of fetch applicants






//// fetch applicants
if(isset($_GET['what']))
	{
	if($_GET['what']=='clearedApplicants')
		{	
		include "vars.php";
		header("Content-Type: application/json");
		$data = file_get_contents("php://input");
						
		
					$connectionString = mysqli_connect($host,$uname,$pwd) ;
						if(!$connectionString)
						{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "failed";
												$PersonalInfo_response["data"] = "";
												echo json_encode($response);
						}
						else
						{
								mysqli_select_db($connectionString, $db);
									$sql = "SELECT * FROM applicant_personal WHERE approval = 'YES'";
										
											
								$result = mysqli_query($connectionString,$sql);
									if($result)
									
									{
										//$row =mysqli_fetch_object($result);
										if(mysqli_num_rows($result)>0)
											{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "ok";
												while($row = $result->fetch_assoc()) {
													$arr[] = $row;	
												}
												$PersonalInfo_response["data"] = $arr;
												echo json_encode($PersonalInfo_response);
											}else{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "not ok";
												$PersonalInfo_response["data"] = "";
												echo json_encode($PersonalInfo_response);
											}
									}
									else
									{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "not ok";
												$PersonalInfo_response["data"] = "";
												echo json_encode($PersonalInfo_response);
									}
									
									
								
									
										
						}
		
		}
	
	}
	

// end of fetch applicants





//// save applicant status
if(isset($_GET['what']))
	{
	if($_GET['what']=='saveApproval')
		{	
		include "vars.php";
		header("Content-Type: application/json");
		$data = file_get_contents("php://input");
						$data = json_decode($data);
						$id = $data->id;
						$status = $data->status;
		
					$connectionString = mysqli_connect($host,$uname,$pwd) ;
						if(!$connectionString)
						{
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "failed";
												$PersonalInfo_response["data"] = "";
												echo json_encode($response);
						}
						else
						{
								mysqli_select_db($connectionString, $db);
									$sql = "UPDATE applicant_personal SET approval ='$status' WHERE applicantId= '$id'";
										
											
								$result = mysqli_query($connectionString,$sql);
									if($result)
									
									{
										
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "ok";
												$PersonalInfo_response["message"] = "The endorsement was successful";
												echo json_encode($PersonalInfo_response);
											
									}
									else
									{
										
												$PersonalInfo_response = array();
												$PersonalInfo_response["status"] = "ok";
												$PersonalInfo_response["message"] = "The endorsement was not successful";
												echo json_encode($PersonalInfo_response);
									}
									
									
								
									
										
						}
		
		}
	
	}
	

// end of fetch applicants

	//////////////////////////////////////////////////////////////////////////////////////
	///////////////// end of save data for leave operation for all other leaves ////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////








// begining of update/save of user creation
if(isset($_GET['usercreation']))
		{

			if(($_GET['usercreation']=="yes"))
			{
				include "vars.php";

				
				/*`userId`, `username`, `userPassword`, `userType`, `status`*/
							// set hedader type
						header("Content-Type: application/json");
						$data = file_get_contents("php://input");
						$data = json_decode($data);
						$username = $data->name;
						$userpassword = $data->password;
						$usertype = $data->type;
						if($usertype=='Admin' or $usertype=='banker' or $usertype=='printer')
						{
							$status = "";
						}else{
							$status = "Unused";
							
							}
						// starting
						$connectionString = mysqli_connect($host,$uname,$pwd) ;
						if(!$connectionString)
								{
														$response = array();
														$response["status"] = "Connection Problems";
														echo json_encode($response);
														
								}
								else
								{
										mysqli_select_db($connectionString, $db);
											$sql = "SELECT * FROM users WHERE username = '$username' AND userPassword = '$userpassword' AND userType='$usertype'";
										$result = mysqli_query($connectionString,$sql);
											if($result)
											
											{
												//$row =mysqli_fetch_object($result);
												if(mysqli_num_rows($result)>0)
													{
														
																$response = array();
																$response["status"] = "exist";
																$response["message"] = "Your Account already exist";
																echo json_encode($response);
															
														// update the stuff
														
				/*`userId`, `username`, `userPassword`, `userType`, `status`*/
										
													}else{
														$mysqlSave = "INSERT INTO users (username, userPassword, userType, status) VALUES ('$username','$userpassword', '$usertype', '$status')";
																
														$result1 =  mysqli_query($connectionString,$mysqlSave);
														if($result1)
															{	
																$response = array();
																$response["status"] = "ok";
																$response["message"] = "Your account was successfully created";
																echo json_encode($response);
															}
															else
															{
$response = array();
																$response["status"] = "not ok";
																$response["message"] = "Your account was not successfully created";
																echo json_encode($response);
															// update the stuff
															}
													}
											}
											else
											{
																$response["status"] = "not ok";
																$response["message"] = "Your account was not successfully created";
																echo json_encode($response);

														
											}
											
						
						
						// ending
						

				
			} 
				
				
		}
	}
	
	// end of update/save user account creation




// begining of fetch ticket
if(isset($_GET['fetchTicket']))
		{

			if(($_GET['fetchTicket']=="yes"))
			{
				include "vars.php";

				
				/*`userId`, `username`, `userPassword`, `userType`, `status`*/
							// set hedader type
						
						// starting
						$connectionString = mysqli_connect($host,$uname,$pwd) ;
						if(!$connectionString)
								{
														$response = array();
														$response["status"] = "Connection Problems";
														echo json_encode($response);
														
								}
								else
								{
										mysqli_select_db($connectionString, $db);
											$sql = "SELECT * FROM users WHERE  userType='applicant' AND status ='unused' LIMIT 1";
										$result = mysqli_query($connectionString,$sql);
											if($result)
											
											{
																$response = array();
																$response["status"] = "ok";
																$row = $result->fetch_assoc();
																$response["data"] = $row;	
												
																echo json_encode($response);
											}
											else
											{
																$response = array();
																$response["status"] = "not ok";
																$response["data"] = "";
																echo json_encode($response);

														
											}
											
						
						
						// ending
						

				
			} 
				
				
		}
	}
	
	// end of fetch account
	
	
// begining of sell ticket
if(isset($_GET['sellTicket']))
		{

			if(($_GET['sellTicket']=="yes"))
			{
				include "vars.php";

				
				/*`userId`, `username`, `userPassword`, `userType`, `status`*/
							// set hedader type
				header("Content-Type: application/json");
						$data = file_get_contents("php://input");
						$data = json_decode($data);
						$username = $data->username;
						$password = $data->password;
						
						// starting
						$connectionString = mysqli_connect($host,$uname,$pwd) ;
						if(!$connectionString)
								{
														$response = array();
														$response["status"] = "Connection Problems";
														echo json_encode($response);
														
								}
								else
								{
										mysqli_select_db($connectionString, $db);
											$sql = "UPDATE users SET status='used' WHERE username = '$username' AND userPassword = '$password'";
										$result = mysqli_query($connectionString,$sql);
											if($result)
											
											{
																$response = array();
																$response["status"] = "ok";
																										
																echo json_encode($response);
											}
											else
											{
																$response = array();
																$response["status"] = "not ok";
																echo json_encode($response);

														
											}
											
						
						
						// ending
						

				
			} 
				
				
		}
	}
	
	// end of update/save user account creation



	?>