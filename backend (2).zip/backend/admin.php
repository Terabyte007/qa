<?php
	session_start();
	include "vars.php";
	include "utility.php";
	include "payment_utility.php";
	header("Content-Type: application/json");
	
	if($_GET['action'] == "get_applicants"){
		$entry_mode = $_GET['entry_mode'];
		
		$response = array();
		
		if($applicants = getApplicants($entry_mode)){
			$response['status'] = "success";
			$response['applicants'] = $applicants;
			$response['message'] = 'Successfully Connected to Server.';
		}
		else{
			$response['status'] = "error";
			$response['applicants'] = array();
			$response['message'] = 'Error Connecting to Server.';
		}
		
		echo json_encode($response);
	}
	
	if($_GET['action'] == "get_applicant_data"){
		$jambRegNo = $_GET['jambRegNo'];
		
		$response = array();
		
		if($applicant_data = getSingleApplicant($jambRegNo)){
			$response['status'] = "success";
			$response['applicant_data'] = $applicant_data;
			$response['applicant_auth_data'] = getApplicantAuthData($jambRegNo);
			$response['message'] = 'Successfully Connected to Server.';
		}
		else{
			$response['status'] = "error";
			$response['applicant_data'] = array();
			$response['applicant_auth_data'] = "";
			$response['message'] = 'Error Connecting to Server.';
		}
		
		echo json_encode($response);
	}
	
	if($_GET['action'] == "create_applicant_auth"){
		$jambRegNo = $_GET['jambRegNo'];
		
		$response = array();
		
		if($applicant_data = getSingleApplicant($jambRegNo)){
			$username = $jambRegNo;
			$password = $applicant_data->surname;
			$usertype = "applicant";
			//echo $password;
			if(getApplicantAuthData($jambRegNo)){
				$response['status'] = "error";
				$response['applicant_auth_data'] = array();
				$response['message'] = 'Error occured. User authentication data already exists.';

			}
			else{
				//createAuthData($username, $password, $usertype);
				if(createAuthData($username, $password, $usertype)){
					$response['status'] = "success";
					$response['applicant_auth_data'] = getApplicantAuthData($jambRegNo);
					$response['message'] = 'Successfully created applicant authentication.';
				}
				else{
					$response['status'] = "error";
					$response['applicant_auth_data'] = getApplicantAuthData($jambRegNo);
					$response['message'] = 'Error encountered while creating applicant authentication.';
				}
			}
		}
		else{
			$response['status'] = "error";
			$response['applicant_auth_data'] = "";
			$response['message'] = 'Error Connecting to Server.';
		}
		
		echo json_encode($response);
	}
	
	if($_GET['action'] == "reset_applicant_auth"){
		$jambRegNo = $_GET['jambRegNo'];
		
		$response = array();
		
		if($applicant_data = getSingleApplicant($jambRegNo)){
			$username = $jambRegNo;
			$password = $applicant_data->surname;
			
			if(getApplicantAuthData($jambRegNo)){
				if(resetAuthPasswordData($username, $password)){
					$response['status'] = "success";
					$response['applicant_auth_data'] = getApplicantAuthData($jambRegNo);
					$response['message'] = 'Successfully created applicant authentication.';
				}
				else{
					$response['status'] = "error";
					$response['applicant_auth_data'] = getApplicantAuthData($jambRegNo);
					$response['message'] = 'Error encountered while reseting applicant authentication. ';
				}
			}
			else{
				$response['status'] = "error";
				$response['applicant_auth_data'] = array();
				$response['message'] = 'Error occured. User authentication data does not exist.';
			}
		}
		else{
			$response['status'] = "error";
			$response['applicant_auth_data'] = "";
			$response['message'] = 'Error occured. Applicant with Jamb Number: '.$jambRegNo.' does not exist.';
		}
		
		echo json_encode($response);
	}
	
	if($_GET['action'] == "delete_applicant_auth"){
		$jambRegNo = $_GET['jambRegNo'];
		
		$response = array();
		
		$username = $jambRegNo;
		if(deleteAuthData($username)){
			$response['status'] = "success";
			$response['applicant_auth_data'] = "";
			$response['message'] = 'Successfully deleted applicant authentication.';
		}
		else{
			$response['status'] = "error";
			$response['applicant_auth_data'] = "";
			$response['message'] = 'Error encountered while deleting applicant authentication. ';
		}
		
		echo json_encode($response);
	}
	
	if($_GET['action'] == "add_additional_applicant_question_subjects"){
		$jambRegNo = $_GET['jambRegNo'];
		$no_of_subjects = $_GET['no_of_subjects'];
		
		$response = array();
		
		if(addAdditionalSampleQuestionSubjects($jambRegNo, $no_of_subjects)){
			$response['status'] = "success";
			$response['message'] = 'Successfully added additional question download subjects.';
		}
		else{
			$response['status'] = "error";
			$response['message'] = 'Error encountered while adding additional question download subjects.';
		}
		
		echo json_encode($response);
	}
	
	if($_GET['action'] == "get_order_applicant_data"){
		$paymentRef = $_GET['orderId'];
		
		$response = array();
		
		$order_info = getOrderDetails($paymentRef);
		$jambRegNo = $order_info->jambRegNo;
		
		if($applicant_data = getSingleApplicant($jambRegNo)){
			$response['status'] = "success";
			$response['applicant_data'] = $applicant_data;
			$response['order_info'] = $order_info;
			$response['message'] = 'Successfully Connected to Server.';
		}
		else{
			$response['status'] = "error";
			$response['applicant_data'] = array();
			$response['order_info'] = array();
			$response['message'] = 'Error Connecting to Server.';
		}
		
		echo json_encode($response);
	}
	
	if($_GET['action'] == "update_departments"){
		//$entry_mode = $_GET['entry_mode'];
		
		$response = array();
		$facs = array();
		$facs[0]['facultyCode'] = 'AGRICULTURE';
		$facs[0]['n_fac'] = 'AGRICULTURE AND FORESTRY';
		$facs[1]['facultyCode'] = 'ARTS';
		$facs[1]['n_fac'] = 'ARTS';
		$facs[2]['facultyCode'] = 'EDUCATION';
		$facs[2]['n_fac'] = 'EDUCATION';
		$facs[3]['facultyCode'] = 'LAW';
		$facs[3]['n_fac'] = 'LAW';
		$facs[4]['facultyCode'] = 'MEDICINE';
		$facs[4]['n_fac'] = 'CLINICAL SCIENCES';
		$facs[5]['facultyCode'] = 'PHARMACY';
		$facs[5]['n_fac'] = 'PHARMACY';
		$facs[6]['facultyCode'] = 'SCIENCE';
		$facs[6]['n_fac'] = 'SCIENCE';
		$facs[7]['facultyCode'] = 'SOCIALSCIENCES';
		$facs[7]['n_fac'] = 'THE SOCIAL SCIENCES';
		$facs[8]['facultyCode'] = 'TECHNOLOGY';
		$facs[8]['n_fac'] = 'TECHNOLOGY';
		$facs[9]['facultyCode'] = 'VETERINARY';
		$facs[9]['n_fac'] = 'VETERINARY MEDICINE';
		
		foreach($facs as $fac){
			updateDepartmentNFAC($fac['facultyCode'], $fac['n_fac']);
		}
		
		$response['status'] = "success";
		$response['message'] = 'Successfully Connected to Server.';
		
		echo json_encode($response);
	}
	
	if($_GET['action'] == "get_reprint_order_applicant_data"){
		$jambRegNo = $_GET['jambRegNo'];
		
		$response = array();
		
		$order_info = getSuccessfulOrderDetails($jambRegNo);
		//$jambRegNo = $order_info->jambRegNo;
		
		if($applicant_data = getSingleApplicant($jambRegNo)){
			$response['status'] = "success";
			$response['applicant_data'] = $applicant_data;
			$response['order_info'] = $order_info;
			$response['message'] = 'Successfully Connected to Server.';
		}
		else{
			$response['status'] = "error";
			$response['applicant_data'] = array();
			$response['order_info'] = array();
			$response['message'] = 'Error Connecting to Server.';
		}
		
		echo json_encode($response);
	}
	
	if($_GET['action'] == "get_reprint_order_screening_applicant_data"){
		$jambRegNo = $_GET['jambRegNo'];
		
		$response = array();
		
		$order_info = getSuccessfulScreeningOrderDetails($jambRegNo);
		//$jambRegNo = $order_info->jambRegNo;
		
		if($applicant_data = getSingleApplicant($jambRegNo)){
			$response['status'] = "success";
			$response['applicant_data'] = $applicant_data;
			$response['order_info'] = $order_info;
			$response['message'] = 'Successfully Connected to Server.';
		}
		else{
			$response['status'] = "error";
			$response['applicant_data'] = array();
			$response['order_info'] = array();
			$response['message'] = 'Error Connecting to Server.';
		}
		
		echo json_encode($response);
	}
	
?>