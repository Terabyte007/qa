<?php
session_start();
include "vars.php";
include "utility.php";
header("Content-Type: application/json");

if($_GET['action'] == "login"){
	//$username = $this->_request->getParam("username");
	//$username = $user->username;
	//$password = $user->password;
	$user = file_get_contents("php://input");
	$user = json_decode($user);
	//echo json_encode($user);
	
	$username = $user->username;
	$password = $user->password;
	
	$response = array();
	
	if($username <> "" && $password <> ""){
		$connectionString = mysqli_connect($host,$uname,$pwd);
		
		if(!$connectionString){
			$response['status'] = "error";
			$response['message'] = 'Login failed. Error Connecting to Server.';
		}
		else{ //echo "login successful";
			$mydb = mysqli_select_db($connectionString, $db);
			if($mydb == false) echo "could notb select database";
			$sql = "SELECT t1.`_id`,`username`, `userType`, `sq_id_fk`, `sq_answer`, `type` FROM `users` t1 inner join `tbl_user_type` t2 on t1.`userType` = t2._id  where username = '$username' and (userpassword = sha1('$password') || userpassword = '$password')";
			$result = mysqli_query($connectionString,$sql);
			
			if($result){
				$rows = mysqli_fetch_object($result);
				if($result->num_rows > 0){
					$userDetails = $rows; 
					if($userDetails->type== "student"){
						$current_session = get_current_session();
						$current_semester = get_current_semester();
						$bio_sql = "SELECT *  FROM `tbl_students_transactions` t1
												inner join `tbl_students_master` t2 
												ON t1.`student_id_fk` = t2._id 
												inner join `tbl_departments` t3
												ON t2.department_id_fk = t3.id
												inner join `tbl_faculty` t4
												ON t3.faculty_id_fk = t4.id
												WHERE t2.`matricNo` LIKE '$username' and t1.session_id_fk = '$current_session'";
						$bio_result = mysqli_query($connectionString, $bio_sql);
						$bio_data = mysqli_fetch_object($bio_result);
						//echo json_encode($bio_data);
						$course_sql = "SELECT t3.course_id_fk FROM `tbl_students_transactions` t1 
										inner join `tbl_students_master` t2 
										ON t1.`student_id_fk` = t2._id inner join `tbl_course_registered` t3 
										ON t3.`student_id_fk` =t2._id WHERE t2.`matricNo` 
										LIKE '$username' and t3.session_id_fk = '$current_session' and t3.`semester_id_fk`='$current_semester'";
						$course_result = mysqli_query($connectionString, $course_sql);
						//$course_data = mysqli_fetch_object($course_result); ///
						$course_data = array();
						while ($row = mysqli_fetch_object($course_result)) {
						$course_data[] = $row->course_id_fk;
						}
						$course_registered = get_course_registered($course_data);
						$number_of_lecturers = get_course_number_of_lecturers($course_data);
						$response['course_registered'] = $course_registered; /////////////////////////////// 
						$response['number_of_lecturers'] = $number_of_lecturers; /////////////////////////////// 
						}
						
					else if ($userDetails->type == "hod")
					{
						$bio_sql = "SELECT * FROM `tbl_staff` t1
									inner join tbl_departments t2
									ON t1.dept_id_fk = t2.id WHERE t1.`pf_number` LIKE '$username'";
						$bio_result = mysqli_query($connectionString, $bio_sql);
						$bio_data = mysqli_fetch_object($bio_result);
						
					}
					else if ($userDetails->type== "qualityassurance")
					{ 
						$bio_sql = "SELECT * FROM `tbl_staff` WHERE `pf_number` LIKE '$username'";
						$bio_result = mysqli_query($connectionString, $bio_sql);
						$bio_data = mysqli_fetch_object($bio_result);
					
						
						}
					else
					{
						$bio_data = array();
					}
					$response['status'] = "success";
					$response['message'] = 'Login was Successful. Please Continue.';
					$response['user_details'] = $userDetails;
					$response['bio_data'] = $bio_data;
					
				}
				else{
					$response['status'] = "error";
					$response['message'] = 'Login failed. Incorrect Login Credentials.';
					$response['user_details'] = array();
				}
			}
		}
	}
	else{
		$response['status'] = "error";
		$response['message'] = 'Login failed. Incorrect Login Credentials.';
		$response['user_details'] = array();
	}
	
	echo json_encode($response);
}

if($_GET['action'] == "change_password"){
	$change_password_data = file_get_contents("php://input");
	$change_password_data = json_decode($change_password_data);
	
	$user_data = $change_password_data->user_data;
	$password_data = $change_password_data->password_data;
	
	$user_id = $user_data->_id;
	$username = $user_data->username;
	$new_password = $password_data->new_password;
	$secret_question = $password_data->secret_question;
	$secret_question_id = $secret_question->id;
	$secret_question_q = $secret_question->question;
	$secret_answer = $password_data->secret_answer;
	
	
	if($username <> "" && $new_password <> "" && $secret_answer <> ""){
		$connectionString = mysqli_connect($host,$uname,$pwd);
		
		if(!$connectionString){
			$response['status'] = "error";
			$response['message'] = 'Password change failed. Error Connecting to Server.';
		}
		else{
			mysqli_select_db($connectionString, $db);
			
			$update_sql = "UPDATE users SET userpassword = sha1('$new_password'), sq_id_fk = '$secret_question_id', sq_answer = '$secret_answer' WHERE _id = $user_id";
			
			if(mysqli_query($connectionString, $update_sql)){
				$sql = "SELECT t1.`_id`,`username`, `userpassword`, `userType`, `sq_id_fk`, `sq_answer`, `type` FROM `users` t1
				        inner join `tbl_user_type` t2 on t1.`userType` = t2._id  where t1._id = '$user_id'";
				$result = mysqli_query($connectionString,$sql);
				
				if($result){
					$rows = mysqli_fetch_object($result);
				if($result->num_rows > 0){
					$userDetails = $rows; 
					if($userDetails->type== "student"){
						$current_session = get_current_session();
						$current_semester = get_current_semester();
						$bio_sql = "SELECT *  FROM `tbl_students_transactions` t1
												inner join `tbl_students_master` t2 
												ON t1.`student_id_fk` = t2._id 
												inner join `tbl_departments` t3
												ON t2.department_id_fk = t3.id
												inner join `tbl_faculty` t4
												ON t3.faculty_id_fk = t4.id
												WHERE t2.`matricNo` LIKE '$username' and t1.session_id_fk = '$current_session'";
						$bio_result = mysqli_query($connectionString, $bio_sql);
						$bio_data = mysqli_fetch_object($bio_result);
						
						$course_sql = "SELECT t3.course_id_fk FROM `tbl_students_transactions` t1 
										inner join `tbl_students_master` t2 
										ON t1.`student_id_fk` = t2._id inner join `tbl_course_registered` t3 
										ON t3.`student_id_fk` =t2._id WHERE t2.`matricNo` 
										LIKE '$username' and t3.session_id_fk = '$current_session' and t3.`semester_id_fk`='$current_semester'";
						$course_result = mysqli_query($connectionString, $course_sql);
						//$course_data = mysqli_fetch_object($course_result); ///
						$course_data = array();
						while ($row = mysqli_fetch_object($course_result)) {
						$course_data[] = $row->course_id_fk;
						}
						$course_registered = get_course_registered($course_data);
						$number_of_lecturers = get_course_number_of_lecturers($course_data);
						$response['course_registered'] = $course_registered; /////////////////////////////// 
						$response['number_of_lecturers'] = $number_of_lecturers; /////////////////////////////// 
						}
						
					else if ($userDetails->type == "hod")
					{
						$bio_sql = "SELECT * FROM `tbl_staff` t1
									inner join tbl_departments t2
									ON t1.dept_id_fk = t2.id WHERE t1.`pf_number` LIKE '$username'";
						$bio_result = mysqli_query($connectionString, $bio_sql);
						$bio_data = mysqli_fetch_object($bio_result);
					}
					else if ($userDetails->type== "qualityassurance")
					{ 
						$bio_sql = "SELECT * FROM `tbl_staff` WHERE `pf_number` LIKE '$username'";
						$bio_result = mysqli_query($connectionString, $bio_sql);
						$bio_data = mysqli_fetch_object($bio_result);
					
						
						}
					else
					{
						$bio_data = array();
					}
					$response['status'] = "success";
					$response['message'] = 'Login was Successful. Please Continue.';
					$response['user_details'] = $userDetails;
					$response['bio_data'] = $bio_data;
					
				}
				else{
					$response['status'] = "error";
					$response['message'] = 'Login failed. Incorrect Login Credentials.';
					$response['user_details'] = array();
				}
					/*$rows = mysqli_fetch_object($result);
					if($result->num_rows > 0){
						$userDetails = $rows;
						$response['status'] = "success";
						$response['message'] = 'Change was Successful. Please Continue.';
						$response['user_details'] = $userDetails;
					}
					else{
						$response['status'] = "error";
						$response['message'] = 'Password change failed. Incorrect Details.';
						$response['user_details'] = array();
					}*/
				}
			}
			else{
				$response['status'] = "error";
				$response['message'] = 'Password change failed. Error Updating Details.';
			}
		}
		$response['username'] = $username;
	}
	else{
		$response['status'] = "error";
		$response['message'] = 'Password Change Failed. Incorrect Details Entered.';
		$response['user_details'] = array();
	}/**/
	
	echo json_encode($response);
}

if($_GET['action'] == "reset_password"){
	$reset_data = file_get_contents("php://input");
	$reset_data = json_decode($reset_data);
	
	//$reset_data = $change_password_data->password_data;
	
	$username = $reset_data->username;
	$secret_question = $reset_data->secret_question;
	$secret_question_id = $secret_question->id;
	$secret_question_q = $secret_question->question;
	$secret_answer = $reset_data->secret_answer;
	
	
	if($username <> "" && $secret_question_id <> "" && $secret_answer <> ""){
		$connectionString = mysqli_connect($host,$uname,$pwd);
		
		if(!$connectionString){
			$response['status'] = "error";
			$response['message'] = 'Password reset failed. Error Connecting to Server.';
		}
		else{
			mysqli_select_db($connectionString, $db);
			
			$sql_a = "select * from users where username = '$username' and  sq_id_fk = '$secret_question_id' and sq_answer = '$secret_answer'";
			$result_a = mysqli_query($connectionString, $sql_a);
			
			if($result_a){
				$rows_a = mysqli_fetch_object($result_a);
				
				if(sizeof($rows_a) > 0){
					$user = $rows_a;
					$usertype = $rows_a->userType;
					
					if($usertype == "applicant"){
						$sql = "select * from appliedcandidates where jambRegNo = '$username'";
						$result = mysqli_query($connectionString,$sql);
						
						if($result){
							$rows = mysqli_fetch_object($result);
							if(sizeof($rows) > 0){
								$userDetails = $rows;
								$surname = $userDetails->surname;
								
								$update_sql = "UPDATE users SET userPassword = sha1('$surname'), sq_id_fk = '0', sq_answer = '' WHERE username = '$username'";
								
								if(mysqli_query($connectionString, $update_sql)){
									$response['status'] = "success";
									$response['message'] = 'Password Reset was Successful. Your new password is now your surname';
								}
								else{
									$response['status'] = "error";
									$response['message'] = 'Password Reset failed. Error Updating Details.';
								}
							}
						}
						else{
							$response['status'] = "error";
							$response['message'] = 'Password Reset failed. Error Updating Details.';
						}
					}
					else{
						$update_sql = "UPDATE users SET userPassword = sha1('$username'), sq_id_fk = '0', sq_answer = '' WHERE username = '$username'";
						
						if(mysqli_query($connectionString, $update_sql)){
							$response['status'] = "success";
							$response['message'] = 'Password Reset was Successful. Your new password is the same as your username';
						}
						else{
							$response['status'] = "error";
							$response['message'] = 'Password Reset failed. Error Updating Details.';
						}
					}
				}
				else{
					//echo json_encode($username);
					$response['status'] = "error";
					$response['message'] = 'Password Reset Failed. Incorrect Details Entered.';
				}
			}
			else{
				$response['status'] = "error";
				$response['message'] = 'Password Reset Failed. Incorrect Details Entered.';
			}
		}
	}
	else{
		$response['status'] = "error";
		$response['message'] = 'Password Reset Failed. Incorrect Details Entered.';
	}/**/
	
	echo json_encode($response);
}

if($_GET['action'] == "secret_questions"){
    //echo "evans";
	$response = array();
	
	$secret_questions = getSecretQuestions();
	//echo json_encode($secret_questions);
	if(sizeof($secret_questions)){
		$response['status'] = "success";
		$response['questions'] = $secret_questions;
		$response['message'] = 'Successfully Connected to Server.';
	}
	else{
		$response['status'] = "error";
		$response['questions'] = array();
		$response['message'] = 'Error Connecting to Server.';
	}
	
	echo json_encode($response);
}

if($_GET['action'] == "getSampleSubjects"){
	$response = array();
	
	$sample_subjects = getSampleQuestionSubjects();
	//echo json_encode($secret_questions);
	if(sizeof($sample_subjects)){
		$response['status'] = "success";
		$response['sample_subjects'] = $sample_subjects;
		$response['message'] = 'Successfully Connected to Server.';
	}
	else{
		$response['status'] = "error";
		$response['sample_subjects'] = array();
		$response['message'] = 'Error Connecting to Server.';
	}
	
	echo json_encode($response);
}

if($_GET['action'] == "save_question_download"){
	$simulate_payment_data = file_get_contents("php://input");
	$simulate_payment_data = json_decode($simulate_payment_data);
	
	$jambRegNo = $_GET['jambRegNo'];
	$samp_qid = $_GET['samp_qid'];
	
	$response = array();
	
	$SampleQuestionDownload_obj = getSampleQuestionDownload($jambRegNo, $samp_qid);
	//echo json_encode($secret_questions);
	if(sizeof($SampleQuestionDownload_obj) > 0){
		$no_of_downloads = $SampleQuestionDownload_obj->no_of_downloads;
		$no_of_downloads++;
		
		if(updateSampleQuestionDownload($jambRegNo, $samp_qid, $no_of_downloads)){
			$response['status'] = "success";
			$response['message'] = 'Successfully Connected to Server.';
		}
		else{
			$response['status'] = "success";
			$response['message'] = 'Error Connecting to Server.';
		}
	}
	else{
		$no_of_downloads = 1;
		
		if(insertSampleQuestionDownload($jambRegNo, $samp_qid, $no_of_downloads)){
			$response['status'] = "success";
			$response['message'] = 'Successfully Connected to Server.';
		}
		else{
			$response['status'] = "success";
			$response['message'] = 'Error Connecting to Server.';
		}
	}
	
	echo json_encode($response);
}


function getDepartmentCode($department)
{
	include "vars.php";
	$connectionString = mysqli_connect($host,$uname,$pwd) ;
		if(!$connectionString)
			{
			  return NULL;
														
			}
			else
			{
			mysqli_select_db($connectionString, $db);
			// SELECT `departmentCode` FROM `department` inner join subject_tbl on subject_name= departmentTitle and sub_code='$department' 
				$sql = "SELECT  `departmentCode` FROM `department` WHERE departmentTitle='$department'";
				$result = mysqli_query($connectionString, $sql);
				if($result)
				{
					if(mysqli_num_rows($result)>0)
					{
					
						$row =  mysqli_fetch_object($result);
						
						return $row->departmentCode;
						
					}else
					{
						
						return NULL;	
					}
				}
			}
	
	
	
}

?>